import SwiftUI
import AVFoundation

// MARK: - Sound Manager
class SoundManager: ObservableObject {
    static let shared = SoundManager()

    private var bgPlayer: AVAudioPlayer?
    
    private var sfxPlayer: AVAudioPlayer?

    // Mirrors of the AppState flags – set these to drive behaviour
    var bgEnabled: Bool = true {
        didSet { bgEnabled ? resumeBG() : pauseBG() }
    }
    var sfxEnabled: Bool = true

    
    private init() {
        setupAudioSession()
        prepareBG()
    }

    private func setupAudioSession() {
        try? AVAudioSession.sharedInstance().setCategory(.ambient, mode: .default, options: [.mixWithOthers])
        try? AVAudioSession.sharedInstance().setActive(true)
    }

    private func prepareBG() {
        guard let url = Bundle.main.url(forResource: "bgmusic", withExtension: "mp3") else { return }
        bgPlayer = try? AVAudioPlayer(contentsOf: url)
        bgPlayer?.numberOfLoops = -1
        bgPlayer?.volume = 0.4
        bgPlayer?.prepareToPlay()
    }

    func startBG() {
        guard bgEnabled else { return }
        if bgPlayer == nil { prepareBG() }
        bgPlayer?.play()
    }

    func pauseBG() { bgPlayer?.pause() }
    func resumeBG() { if bgEnabled { bgPlayer?.play() } }

    func playSFX(_ name: String) {
        guard sfxEnabled else { return }
        guard let url = Bundle.main.url(forResource: name, withExtension: "mp3") else { return }
        sfxPlayer = try? AVAudioPlayer(contentsOf: url)
        sfxPlayer?.volume = 0.9
        sfxPlayer?.play()
    }

    func playTap()           { playSFX("tap") }
    func playCorrect()       { playSFX("correctanswer") }
    func playError()         { playSFX("error") }
    func playWinningScreen() { playSFX("winningscreen") }
}

// MARK: - Main App Entry Point
@main
struct RoadSafetyApp: App {
    @StateObject private var appState = AppState()
    
    var body: some Scene {
        WindowGroup {
            ZStack {
                NavigationStack {
                    HomeView()
                }
                .environmentObject(appState)
                
                SplashView()
            }
            .onAppear {
                SoundManager.shared.bgEnabled = appState.bgSoundEnabled
                SoundManager.shared.sfxEnabled = appState.sfxEnabled
                SoundManager.shared.startBG()
            }
        }
    }
}

// MARK: - Models
enum PuzzleType: String, Codable {
    case choice, dragDrop, jigsaw, pathfinding, touch
}

enum CardType: String, Codable {
    case learn, puzzle
}

enum CardVisual: String, Hashable, CaseIterable {
    // Pedestrian Levels
    case pedestrianCarsMoving_learn, pedestrianBallRolling_learn, pedestrianRedLight_puzzle, pedestrianGreenLight_safe
    case pedestrianDontCross_learn, pedestrianTouchSign_interactive, pedestrianSignJigsaw_puzzle
    case pedestrianLevel3Learn, pedestrianLevel3Puzzle1, pedestrianLevel3Puzzle2
    
    // Cyclist Levels
    case cyclistOnRoad_learn, cyclistHelmetDrag_puzzle, cyclistWearingHelmet_safe
    case cyclistTurnLeft_learn, cyclistTouchTurnSign_interactive, cyclistTurnSignJigsaw_puzzle
    case cyclistLevel3Learn, cyclistLevel3Puzzle1, cyclistLevel3Puzzle2
    
    // Driver Levels
    case driverInCar_learn, driverSeatbeltDrag_puzzle, driverWithSeatbelt_safe
    case driverStraightNoUTurn_learn, driverTouchNoUTurn_interactive, driverNoUTurnJigsaw_puzzle
    case driverLevel3Learn, driverLevel3Puzzle1, driverLevel3Puzzle2
    
    // Traffic Levels
    case trafficPersonOffZebra_learn, trafficDragToZebra_puzzle, trafficPersonOnZebra_safe
    case trafficLevel2Learn, trafficLevel2Puzzle1, trafficLevel2Puzzle2
    case trafficLevel3Learn, trafficLevel3Puzzle1, trafficLevel3Puzzle2
    
    // Racing
    case racing_puzzle
}

struct Card: Identifiable, Hashable {
    let id = UUID()
    let type: CardType
    let visual: CardVisual
    let puzzleType: PuzzleType?
    let question: String?
    let options: [String]?
    let correctAnswer: String?
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
    
    static func == (lhs: Card, rhs: Card) -> Bool {
        lhs.id == rhs.id
    }
}

struct LevelCategory: Identifiable {
    let id: String
    let name: String
    let icon: String
    let color: Color
    let secondaryColor: Color
    let levels: [Int]
}

enum PerformanceRating {
    case good, wellDone, excellent
    
    var icon: String {
        switch self {
        case .good: return "🙂"
        case .wellDone: return "🔥"
        case .excellent: return "🔥🔥"
        }
    }
    
    var message: String {
        switch self {
        case .good: return "Good Job!"
        case .wellDone: return "Well Done!"
        case .excellent: return "Excellent"
        }
    }
    
    var color: Color {
        switch self {
        case .good: return .green
        case .wellDone: return .orange
        case .excellent: return .red
        }
    }
    
    static func from(score: Int, totalPossible: Int) -> PerformanceRating {
        guard totalPossible > 0 else { return .good }
        let percentage = Double(score) / Double(totalPossible)
        if percentage >= 0.8 {
            return .excellent
        } else if percentage >= 0.5 {
            return .wellDone
        } else {
            return .good
        }
    }
}

struct GridCell {
    let row: Int
    let col: Int
    var isWalkable: Bool
    var isStart: Bool = false
    var isGoal: Bool = false
    var isRoad: Bool = false
    var hasTrafficLight: Bool = false
    var trafficLightColor: TrafficLightColor = .red
    var hasZebraCrossing: Bool = false
    var hasBikeLane: Bool = false
    var hasSign: String? = nil
    var isNoTurnZone: Bool = false
    var isSchoolZone: Bool = false
    var hasPedestrianSignal: Bool = false
    var pedestrianSignalColor: TrafficLightColor = .red
    var hasMovingCar: Bool = false
    var carDirection: CarDirection = .horizontal
}

enum TrafficLightColor {
    case red, yellow, green
    
    var color: Color {
        switch self {
        case .red: return .red
        case .yellow: return .yellow
        case .green: return .green
        }
    }
}

// MARK: - Racing Models
struct Pedestrian: Identifiable {
    let id = UUID()
    var xOffset: CGFloat 
    var direction: CGFloat
}

struct RacingObstacle: Identifiable {
    let id = UUID()
    var type: ObstacleType
    var yPosition: CGFloat
    var lightState: TrafficLightColor = .green
    var pedestrians: [Pedestrian] = []
    var lightTimer: Double = 0
}

enum ObstacleType {
    case zebraCrossing
    case noEntrySign(lane: Int)
    case pedestrianCrossing // Re-using or replacing
    case oncomingCar(lane: Int)
}

class RacingGameState: ObservableObject {
    @Published var playerLane: Int = 1
    @Published var obstacles: [RacingObstacle] = []
    @Published var distance: Int = 0
    @Published var gameOver: Bool = false
    @Published var speed: CGFloat = 2.0
    @Published var isStopped: Bool = false
    @Published var isPaused: Bool = false
}

enum CarDirection {
    case horizontal, vertical
}

// MARK: - Level Content Provider
class LevelContentProvider {
    
    static func getPedestrianLevel(level: Int) -> [Card] {
        switch level {
        case 1:
            return [
                Card(type: .learn, visual: .pedestrianCarsMoving_learn, puzzleType: nil, 
                     question: "Watch out for moving cars!", options: nil, correctAnswer: nil),
                Card(type: .learn, visual: .pedestrianBallRolling_learn, puzzleType: nil, 
                     question: "The ball rolls into the road!", options: nil, correctAnswer: nil),
                Card(type: .puzzle, visual: .pedestrianRedLight_puzzle, puzzleType: .touch, 
                     question: "When can you cross?", options: nil, correctAnswer: nil),
                Card(type: .learn, visual: .pedestrianGreenLight_safe, puzzleType: nil, 
                     question: "Great! Green means go.", options: nil, correctAnswer: nil)
            ]
        case 2:
            return [
                Card(type: .learn, visual: .pedestrianDontCross_learn, puzzleType: nil, 
                     question: "Don't cross when the hand is red.", options: nil, correctAnswer: nil),
                Card(type: .puzzle, visual: .pedestrianTouchSign_interactive, puzzleType: .touch, 
                     question: "Tap the Stop sign!", options: nil, correctAnswer: nil),
                Card(type: .puzzle, visual: .pedestrianSignJigsaw_puzzle, puzzleType: .jigsaw, 
                     question: "Assemble the walker!", options: nil, correctAnswer: nil)
            ]
        case 3:
            return [
                Card(type: .learn, visual: .pedestrianLevel3Learn, puzzleType: nil,
                     question: "Find the safe path across the busy intersection!", options: nil, correctAnswer: nil),
                Card(type: .puzzle, visual: .pedestrianLevel3Puzzle1, puzzleType: .pathfinding,
                     question: "Navigate to the other side safely", options: nil, correctAnswer: nil),
                Card(type: .puzzle, visual: .pedestrianLevel3Puzzle2, puzzleType: .choice,
                     question: "When is it safe to cross?", options: ["When cars are moving", "When pedestrian light is green", "When you're in a hurry"], correctAnswer: "When pedestrian light is green")
            ]
        default:
            return []
        }
    }
    
    static func getCyclistLevel(level: Int) -> [Card] {
        switch level {
        case 1:
            return [
                Card(type: .learn, visual: .cyclistOnRoad_learn, puzzleType: nil, 
                     question: "Stay in the bike lane.", options: nil, correctAnswer: nil),
                Card(type: .puzzle, visual: .cyclistHelmetDrag_puzzle, puzzleType: .dragDrop, 
                     question: "Put on your helmet!", options: nil, correctAnswer: nil),
                Card(type: .learn, visual: .cyclistWearingHelmet_safe, puzzleType: nil, 
                     question: "Safety first!", options: nil, correctAnswer: nil)
            ]
        case 2:
            return [
                Card(type: .learn, visual: .cyclistTurnLeft_learn, puzzleType: nil, 
                     question: "Signal before turning.", options: nil, correctAnswer: nil),
                Card(type: .puzzle, visual: .cyclistTouchTurnSign_interactive, puzzleType: .touch, 
                     question: "Tap the hand signal.", options: nil, correctAnswer: nil),
                Card(type: .puzzle, visual: .cyclistTurnSignJigsaw_puzzle, puzzleType: .jigsaw, 
                     question: "Fix the bike!", options: nil, correctAnswer: nil)
            ]
        case 3:
            return [
                Card(type: .learn, visual: .cyclistLevel3Learn, puzzleType: nil,
                     question: "Navigate through traffic using bike lanes!", options: nil, correctAnswer: nil),
                Card(type: .puzzle, visual: .cyclistLevel3Puzzle1, puzzleType: .pathfinding,
                     question: "Find the bike lane path to your destination", options: nil, correctAnswer: nil),
                Card(type: .puzzle, visual: .cyclistLevel3Puzzle2, puzzleType: .dragDrop,
                     question: "Place the bike lane signs correctly", options: nil, correctAnswer: nil)
            ]
        default:
            return []
        }
    }
    
    static func getDriverLevel(level: Int) -> [Card] {
        switch level {
        case 1:
            return [
                Card(type: .learn, visual: .driverInCar_learn, puzzleType: nil, 
                     question: "Always buckle up.", options: nil, correctAnswer: nil),
                Card(type: .puzzle, visual: .driverSeatbeltDrag_puzzle, puzzleType: .dragDrop, 
                     question: "Fasten your seatbelt!", options: nil, correctAnswer: nil),
                Card(type: .learn, visual: .driverWithSeatbelt_safe, puzzleType: nil, 
                     question: "Click it or ticket!", options: nil, correctAnswer: nil)
            ]
        case 2:
            return [
                Card(type: .learn, visual: .driverStraightNoUTurn_learn, puzzleType: nil, 
                     question: "No U-Turns here.", options: nil, correctAnswer: nil),
                Card(type: .puzzle, visual: .driverTouchNoUTurn_interactive, puzzleType: .touch, 
                     question: "Tap the No U-Turn sign.", options: nil, correctAnswer: nil),
                Card(type: .puzzle, visual: .driverNoUTurnJigsaw_puzzle, puzzleType: .jigsaw, 
                     question: "Build the car.", options: nil, correctAnswer: nil)
            ]
        case 3:
            return [
                Card(type: .learn, visual: .driverLevel3Learn, puzzleType: nil,
                     question: "Navigate the intersection with traffic lights!", options: nil, correctAnswer: nil),
                Card(type: .puzzle, visual: .driverLevel3Puzzle1, puzzleType: .pathfinding,
                     question: "Drive to the destination following traffic rules", options: nil, correctAnswer: nil),
                Card(type: .puzzle, visual: .driverLevel3Puzzle2, puzzleType: .choice,
                     question: "What should you do at a yellow light?", options: ["Speed up", "Stop if safe", "Ignore it"], correctAnswer: "Stop if safe")
            ]
        default:
            return []
        }
    }
    
    static func getTrafficLevel(level: Int) -> [Card] {
        switch level {
        case 1:
            return [
                Card(type: .learn, visual: .trafficPersonOffZebra_learn, puzzleType: nil, 
                     question: "Watch for hazards.", options: nil, correctAnswer: nil),
                Card(type: .puzzle, visual: .trafficDragToZebra_puzzle, puzzleType: .dragDrop, 
                     question: "Place the person on zebra crossing.", options: nil, correctAnswer: nil),
                Card(type: .learn, visual: .trafficPersonOnZebra_safe, puzzleType: nil, 
                     question: "Safe now.", options: nil, correctAnswer: nil)
            ]
        case 2:
            return [
                Card(type: .learn, visual: .trafficLevel2Learn, puzzleType: nil,
                     question: "Learn the traffic light sequence!", options: nil, correctAnswer: nil),
                Card(type: .puzzle, visual: .trafficLevel2Puzzle1, puzzleType: .touch,
                     question: "Watch the blinking lights!", options: nil, correctAnswer: nil),
                Card(type: .puzzle, visual: .trafficLevel2Puzzle2, puzzleType: .choice,
                     question: "What is the correct order?", 
                     options: ["Red → Green → Yellow", "Red → Yellow → Green", "Green → Yellow → Red"], 
                     correctAnswer: "Red → Yellow → Green")
            ]
        case 3:
            return [
                Card(type: .learn, visual: .trafficLevel3Learn, puzzleType: nil,
                     question: "Complex intersection! Watch all traffic signals.", options: nil, correctAnswer: nil),
                Card(type: .puzzle, visual: .trafficLevel3Puzzle1, puzzleType: .pathfinding,
                     question: "Navigate through the busy intersection safely", options: nil, correctAnswer: nil),
                Card(type: .puzzle, visual: .trafficLevel3Puzzle2, puzzleType: .touch,
                     question: "Tap all safety features you see", options: nil, correctAnswer: nil)
            ]
        default:
            return []
        }
    }
    
    static func getRacingLevel(level: Int) -> [Card] {
        return [
            Card(type: .puzzle, visual: .racing_puzzle, puzzleType: .pathfinding,
                 question: "Race and stay safe!", options: nil, correctAnswer: nil)
        ]
    }
}

// MARK: - Data
struct GameData {
    static let categories: [LevelCategory] = [
        LevelCategory(id: "pedestrian", name: "Pedestrian", icon: "figure.walk", 
                      color: .blue, secondaryColor: .cyan, levels: [1, 2, 3]),
        LevelCategory(id: "cyclist", name: "Cyclist", icon: "bicycle", 
                      color: .green, secondaryColor: .mint, levels: [1, 2, 3]),
        LevelCategory(id: "driver", name: "Driver", icon: "car.fill", 
                      color: .orange, secondaryColor: .yellow, levels: [1, 2, 3]),
        LevelCategory(id: "traffic", name: "Traffic", icon: "cone.fill", 
                      color: .red, secondaryColor: .pink, levels: [1, 2, 3]),
        LevelCategory(id: "racing", name: "Racing", icon: "sportscourt.fill", 
                      color: .purple, secondaryColor: .pink, levels: [1])
    ]
    
    static func getCards(for categoryId: String, level: Int) -> [Card] {
        switch categoryId {
        case "pedestrian":
            return LevelContentProvider.getPedestrianLevel(level: level)
        case "cyclist":
            return LevelContentProvider.getCyclistLevel(level: level)
        case "driver":
            return LevelContentProvider.getDriverLevel(level: level)
        case "traffic":
            return LevelContentProvider.getTrafficLevel(level: level)
        case "racing":
            return LevelContentProvider.getRacingLevel(level: level)
        default:
            return []
        }
    }
}

// MARK: - Array Extension
extension Array {
    subscript(safe index: Int) -> Element? {
        return indices.contains(index) ? self[index] : nil
    }
}

// MARK: - Fun Background Extension
extension View {
    func funBackground() -> some View {
        self.background(
            LinearGradient(
                gradient: Gradient(colors: [
                    Color(red: 0.2, green: 0.5, blue: 0.9),  // Sky blue
                    Color(red: 0.8, green: 0.3, blue: 0.5),  // Pink
                    Color(red: 0.3, green: 0.8, blue: 0.6)   // Mint
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        )
    }
    
    func funOverlay() -> some View {
        self.overlay(
            ZStack {
                Circle()
                    .fill(Color.white.opacity(0.2))
                    .frame(width: 100, height: 100)
                    .offset(x: -50, y: -100)
                
                Circle()
                    .fill(Color.white.opacity(0.15))
                    .frame(width: 150, height: 150)
                    .offset(x: 100, y: 50)
                
                ForEach(0..<10) { i in
                    Image(systemName: "star.fill")
                        .font(.system(size: CGFloat.random(in: 10...20)))
                        .foregroundColor(.yellow.opacity(0.3))
                        .position(
                            x: CGFloat.random(in: 0...400),
                            y: CGFloat.random(in: 0...800)
                        )
                }
            }
        )
    }
}

// MARK: - State Management
class AppState: ObservableObject {
    @Published var progress: [String: [Int: LevelProgress]] = [:]
    @Published var isSimpleMode: Bool = true
    @Published var bgSoundEnabled: Bool = true
    @Published var sfxEnabled: Bool = true
    
    struct LevelProgress: Codable {
        var highScore: Int
        var isUnlocked: Bool
    }
    
    init() {
        loadProgress()
        if let storedMode = UserDefaults.standard.object(forKey: "isSimpleMode") as? Bool {
            self.isSimpleMode = storedMode
        } else {
            self.isSimpleMode = true // Default
        }
        if let stored = UserDefaults.standard.object(forKey: "bgSoundEnabled") as? Bool {
            self.bgSoundEnabled = stored
        }
        if let stored = UserDefaults.standard.object(forKey: "sfxEnabled") as? Bool {
            self.sfxEnabled = stored
        }
    }
    
    func toggleSimpleMode() {
        isSimpleMode.toggle()
        UserDefaults.standard.set(isSimpleMode, forKey: "isSimpleMode")
    }
    
    func toggleBGSound() {
        bgSoundEnabled.toggle()
        UserDefaults.standard.set(bgSoundEnabled, forKey: "bgSoundEnabled")
        SoundManager.shared.bgEnabled = bgSoundEnabled
    }
    
    func toggleSFX() {
        sfxEnabled.toggle()
        UserDefaults.standard.set(sfxEnabled, forKey: "sfxEnabled")
        SoundManager.shared.sfxEnabled = sfxEnabled
    }
    
    func loadProgress() {
        if let data = UserDefaults.standard.data(forKey: "roadSafetyProgress"),
           let decoded = try? JSONDecoder().decode([String: [Int: LevelProgress]].self, from: data) {
            self.progress = decoded
        } else {
            self.progress = [
                "pedestrian": [1: LevelProgress(highScore: 0, isUnlocked: true)],
                "cyclist": [1: LevelProgress(highScore: 0, isUnlocked: true)],
                "driver": [1: LevelProgress(highScore: 0, isUnlocked: true)],
                "traffic": [1: LevelProgress(highScore: 0, isUnlocked: true)],
                "racing": [1: LevelProgress(highScore: 0, isUnlocked: true)]
            ]
        }
    }
    
    func saveProgress() {
        if let data = try? JSONEncoder().encode(progress) {
            UserDefaults.standard.set(data, forKey: "roadSafetyProgress")
        }
    }
    
    var totalScore: Int {
        progress.values.reduce(0) { total, category in
            total + category.values.reduce(0) { $0 + $1.highScore }
        }
    }
    
    func getHighScore(categoryId: String, level: Int) -> Int {
        progress[categoryId]?[level]?.highScore ?? 0
    }
    
    func isLevelUnlocked(categoryId: String, level: Int) -> Bool {
        if level == 1 { return true }
        return progress[categoryId]?[level]?.isUnlocked ?? false
    }
    
    func saveHighScore(categoryId: String, level: Int, score: Int) {
        var categoryProgress = progress[categoryId] ?? [:]
        var levelProgress = categoryProgress[level] ?? LevelProgress(highScore: 0, isUnlocked: false)
        
        if score > levelProgress.highScore {
            levelProgress.highScore = score
            levelProgress.isUnlocked = true
            categoryProgress[level] = levelProgress
            progress[categoryId] = categoryProgress
            saveProgress()
        }
    }
    
    func unlockLevel(categoryId: String, level: Int) {
        var categoryProgress = progress[categoryId] ?? [:]
        var levelProgress = categoryProgress[level] ?? LevelProgress(highScore: 0, isUnlocked: false)
        
        levelProgress.isUnlocked = true
        categoryProgress[level] = levelProgress
        progress[categoryId] = categoryProgress
        saveProgress()
    }
}

// MARK: - Splash View
struct SplashView: View {
    @State private var scale: CGFloat = 0.8
    @State private var opacity: Double = 1.0
    @State private var isVisible: Bool = true
    
    var body: some View {
        Group {
            if isVisible {
                ZStack {
                    // Background gradient - matching the image
                    LinearGradient(
                        colors: [
                            Color(red: 0.25, green: 0.45, blue: 0.75),  // Top blue
                            Color(red: 0.35, green: 0.55, blue: 0.85),  // Mid blue
                            Color(red: 0.45, green: 0.65, blue: 0.95)   // Bottom lighter blue
                        ],
                        startPoint: .top,
                        endPoint: .bottom
                    )
                    .ignoresSafeArea()
                    
                    VStack(spacing: 30) {
                        Spacer()
                        
                        // Traffic Light Design - matching the image
                        ZStack {
                            // Traffic light housing with rounded corners
                            RoundedRectangle(cornerRadius: 30)
                                .fill(
                                    LinearGradient(
                                        colors: [Color.black, Color(white: 0.15)],
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    )
                                )
                                .frame(width: 140, height: 300)
                                .shadow(color: .black.opacity(0.5), radius: 25, x: 0, y: 15)
                            
                            // Traffic light bulbs
                            VStack(spacing: 25) {
                                // Red light - ILLUMINATED
                                ZStack {
                                    Circle()
                                        .fill(
                                            RadialGradient(
                                                colors: [Color.red, Color.red.opacity(0.7)],
                                                center: .center,
                                                startRadius: 5,
                                                endRadius: 35
                                            )
                                        )
                                        .frame(width: 70, height: 70)
                                        .shadow(color: .red.opacity(0.8), radius: 30, x: 0, y: 0)
                                    
                                    Circle()
                                        .fill(Color.red.opacity(0.3))
                                        .frame(width: 70, height: 70)
                                        .blur(radius: 15)
                                }
                                
                                // Yellow light - dim
                                Circle()
                                    .fill(Color(red: 0.4, green: 0.35, blue: 0.1))
                                    .frame(width: 70, height: 70)
                                
                                // Green light - dim
                                Circle()
                                    .fill(Color(red: 0.1, green: 0.3, blue: 0.15))
                                    .frame(width: 70, height: 70)
                            }
                            .padding(.vertical, 25)
                        }
                        
                        // App Title
                        Text("Road Quest")
                            .font(.system(size: 48, weight: .black, design: .rounded))
                            .foregroundColor(.white)
                            .shadow(color: .black.opacity(0.3), radius: 8, x: 0, y: 4)
                            .padding(.top, 20)
                        
                        // Tagline
                        Text("Learn Safety • Have Fun")
                            .font(.system(size: 18, weight: .semibold, design: .rounded))
                            .foregroundColor(.white.opacity(0.9))
                            .tracking(1)
                        
                        Spacer()
                        Spacer()
                    }
                    .scaleEffect(scale)
                    .opacity(opacity)
                }
                .transition(.opacity)
                .zIndex(1000) // Ensure splash is on top
            }
        }
        .onAppear {
            // Smooth entrance animation
            withAnimation(.spring(response: 0.8, dampingFraction: 0.7)) {
                scale = 1.0
            }
            
            // Auto-dismiss after 2.5 seconds
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                withAnimation(.easeOut(duration: 0.5)) {
                    opacity = 0.0
                }
                // Remove from view hierarchy completely
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    isVisible = false
                }
            }
        }
    }
}

// MARK: - Home View
struct HomeView: View {
    @EnvironmentObject var appState: AppState
    @State private var showSettings = false
    
    var body: some View {
        GeometryReader { geo in
            let isLarge = geo.size.width > 600
            let titleSize: CGFloat = isLarge ? min(geo.size.width * 0.07, 80) : 42
            let scoreSize: CGFloat = isLarge ? min(geo.size.width * 0.045, 52) : 34
            let gridMin: CGFloat = isLarge ? min(geo.size.width * 0.28, 280) : 150
            let hPad: CGFloat = isLarge ? geo.size.width * 0.05 : 16

            ZStack {
                LinearGradient(colors: [.cyan.opacity(0.3), .purple.opacity(0.3)],
                               startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()

                ScrollView {
                    VStack(spacing: isLarge ? 40 : 30) {
                        // Header Area
                        VStack(spacing: isLarge ? 20 : 15) {
                            HStack {
                                Spacer()
                                
                                HStack(spacing: 15) {
                                    Button(action: {
                                        SoundManager.shared.playTap()
                                        withAnimation { appState.toggleSimpleMode() }
                                    }) {
                                        HStack(spacing: 5) {
                                            Image(systemName: appState.isSimpleMode ? "eye.slash.fill" : "eye.fill")
                                            Text(appState.isSimpleMode ? "Simple" : "Full")
                                        }
                                        .font(.system(isLarge ? .title2 : .headline, design: .rounded))
                                        .foregroundColor(.white)
                                        .padding(.horizontal, isLarge ? 22 : 15)
                                        .padding(.vertical, isLarge ? 12 : 8)
                                        .background(.ultraThinMaterial)
                                        .clipShape(Capsule())
                                    }
                                    
                                    Button(action: {
                                        SoundManager.shared.playTap()
                                        showSettings = true
                                    }) {
                                        Image(systemName: "exclamationmark")
                                            .font(.system(size: isLarge ? 22 : 18, weight: .black))
                                            .foregroundColor(.white)
                                            .frame(width: isLarge ? 48 : 36, height: isLarge ? 48 : 36)
                                            .background(Color.white.opacity(0.2))
                                            .clipShape(Circle())
                                    }
                                }
                                .padding(.trailing, isLarge ? 30 : 20)
                            }

                            Text("ROAD SAFETY")
                                .font(.system(size: titleSize, weight: .black, design: .rounded))
                                .foregroundStyle(.white)
                                .shadow(color: .black.opacity(0.2), radius: 5, x: 0, y: 5)

                            HStack {
                                Image(systemName: "star.fill")
                                    .foregroundStyle(.yellow)
                                    .font(isLarge ? .largeTitle : .title2)
                                Text("\(appState.totalScore)")
                                    .font(.system(size: scoreSize, weight: .black, design: .rounded))
                                    .foregroundStyle(.orange)
                            }
                            .padding(.horizontal, isLarge ? 35 : 25)
                            .padding(.vertical, isLarge ? 16 : 12)
                            .background(.white)
                            .clipShape(Capsule())
                            .shadow(color: .black.opacity(0.1), radius: 10, x: 0, y: 5)
                        }
                        .padding(.top, isLarge ? 50 : 40)

                        LazyVGrid(columns: [GridItem(.adaptive(minimum: gridMin))], spacing: isLarge ? 28 : 20) {
                            ForEach(GameData.categories) { category in
                                NavigationLink(destination: LevelSelectionView(category: category)) {
                                    CategoryCard(category: category, screenWidth: geo.size.width)
                                }
                                .simultaneousGesture(TapGesture().onEnded {
                                    SoundManager.shared.playTap()
                                })
                            }
                        }
                        .padding(.horizontal, hPad)
                        .padding(.bottom, isLarge ? 30 : 16)
                    }
                }
            }
            .sheet(isPresented: $showSettings) {
                VStack(spacing: 30) {
                    Text("Settings")
                        .font(.system(.title, design: .rounded, weight: .black))
                        .padding(.top)
                    
                    VStack(spacing: 20) {
                        Toggle("Background Music", isOn: Binding(
                            get: { appState.bgSoundEnabled },
                            set: { _ in 
                                SoundManager.shared.playTap()
                                appState.toggleBGSound() 
                            }
                        ))
                        .font(.headline)
                        
                        Toggle("Sound Effects", isOn: Binding(
                            get: { appState.sfxEnabled },
                            set: { _ in 
                                SoundManager.shared.playTap()
                                appState.toggleSFX() 
                            }
                        ))
                        .font(.headline)
                    }
                    .padding()
                    .background(Color.white.opacity(0.1))
                    .cornerRadius(20)
                    .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.gray.opacity(0.2), lineWidth: 1))
                    
                    Button(action: {
                        SoundManager.shared.playTap()
                        showSettings = false
                    }) {
                        Text("Done")
                            .font(.headline.bold())
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.blue)
                            .clipShape(Capsule())
                    }
                    .padding(.top)
                    
                    Spacer()
                }
                .padding(30)
                .background(
                    LinearGradient(colors: [.cyan.opacity(0.1), .blue.opacity(0.1)], startPoint: .top, endPoint: .bottom)
                )
                .presentationDetents([.medium])
                .presentationDragIndicator(.visible)
            }
        }
    }
}

struct CategoryCard: View {
    let category: LevelCategory
    var screenWidth: CGFloat = 390
    @EnvironmentObject var appState: AppState

    var isLarge: Bool { screenWidth > 600 }
    var circleSize: CGFloat { isLarge ? min(screenWidth * 0.14, 140) : 80 }
    var iconSize: CGFloat { isLarge ? min(screenWidth * 0.07, 70) : 40 }
    var nameSize: CGFloat { isLarge ? min(screenWidth * 0.032, 32) : 22 }
    var vPad: CGFloat { isLarge ? 50 : 35 }
    var cornerR: CGFloat { isLarge ? 40 : 32 }

    var body: some View {
        VStack(spacing: isLarge ? 20 : 15) {
            ZStack {
                Circle()
                    .fill(.white.opacity(0.2))
                    .frame(width: circleSize, height: circleSize)

                Image(systemName: category.icon)
                    .font(.system(size: iconSize, weight: .bold))
                    .foregroundStyle(.white)
            }

            if !appState.isSimpleMode {
                Text(category.name)
                    .font(.system(size: nameSize, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
            }
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, vPad)
        .background(
            ZStack {
                LinearGradient(colors: [category.color, category.secondaryColor],
                               startPoint: .topLeading, endPoint: .bottomTrailing)
                LinearGradient(colors: [.white.opacity(0.3), .clear],
                               startPoint: .topLeading, endPoint: .bottomTrailing)
            }
        )
        .clipShape(RoundedRectangle(cornerRadius: cornerR))
        .shadow(color: category.color.opacity(0.4), radius: isLarge ? 20 : 15, x: 0, y: isLarge ? 16 : 12)
    }
}

// MARK: - Level Selection View
struct LevelSelectionView: View {
    let category: LevelCategory
    @EnvironmentObject var appState: AppState

    var body: some View {
        GeometryReader { geo in
            let isLarge = geo.size.width > 600
            let gridMin: CGFloat = isLarge ? min(geo.size.width * 0.22, 240) : 100
            let hPad: CGFloat = isLarge ? geo.size.width * 0.06 : 16

            ZStack {
                LinearGradient(colors: [category.color.opacity(0.3), category.secondaryColor.opacity(0.3)],
                               startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()

                VStack(spacing: isLarge ? 28 : 20) {
                    if !appState.isSimpleMode {
                        HStack(spacing: 20) {
                            HStack {
                                Image(systemName: "checkmark.circle.fill")
                                    .foregroundStyle(.green)
                                Text("\(completedCount)/\(category.levels.count)")
                            }
                            HStack {
                                Image(systemName: "star.fill")
                                    .foregroundStyle(.yellow)
                                Text("\(categoryTotalScore)")
                            }
                        }
                        .font(isLarge ? .title.bold() : .title2.bold())
                        .padding(isLarge ? 20 : 14)
                        .background(.white.opacity(0.8))
                        .clipShape(Capsule())
                        .padding(.vertical, isLarge ? 16 : 8)
                    }

                    ScrollView {
                        LazyVGrid(columns: [GridItem(.adaptive(minimum: gridMin))], spacing: isLarge ? 28 : 20) {
                            ForEach(category.levels, id: \.self) { level in
                                let isUnlocked = appState.isLevelUnlocked(categoryId: category.id, level: level)
                                let highScore = appState.getHighScore(categoryId: category.id, level: level)

                                NavigationLink(destination: GamePlayView(category: category, level: level)) {
                                    LevelCard(level: level, isUnlocked: isUnlocked, highScore: highScore, screenWidth: geo.size.width)
                                }
                                .disabled(!isUnlocked)
                                .simultaneousGesture(TapGesture().onEnded {
                                    if isUnlocked {
                                        SoundManager.shared.playTap()
                                    }
                                })
                            }
                        }
                        .padding(.horizontal, hPad)
                        .padding(.vertical, isLarge ? 20 : 12)
                    }
                }
            }
        }
        .navigationTitle(appState.isSimpleMode ? "" : category.name)
    }

    var completedCount: Int {
        category.levels.filter { appState.getHighScore(categoryId: category.id, level: $0) > 0 }.count
    }

    var categoryTotalScore: Int {
        category.levels.reduce(0) { $0 + appState.getHighScore(categoryId: category.id, level: $1) }
    }
}

struct LevelCard: View {
    let level: Int
    let isUnlocked: Bool
    let highScore: Int
    var screenWidth: CGFloat = 390

    var isLarge: Bool { screenWidth > 600 }
    var numberSize: CGFloat { isLarge ? min(screenWidth * 0.1, 100) : 50 }
    var badgeSize: CGFloat { isLarge ? 44 : 30 }
    var badgeOffset: CGFloat { isLarge ? 14 : 10 }
    var cornerR: CGFloat { isLarge ? 28 : 20 }

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: cornerR)
                .fill(isUnlocked ? Color.white : Color.gray.opacity(0.5))
                .shadow(radius: isLarge ? 8 : 5)
                .aspectRatio(1, contentMode: .fit)

            VStack(spacing: isLarge ? 12 : 6) {
                Text("\(level)")
                    .font(.system(size: numberSize, weight: .black))
                    .foregroundStyle(isUnlocked ? .black : .gray)

                if !isUnlocked {
                    Image(systemName: "lock.fill")
                        .font(isLarge ? .largeTitle : .title)
                        .foregroundStyle(.gray)
                }
            }

            if highScore > 0 {
                VStack {
                    HStack {
                        Spacer()
                        ZStack {
                            Circle()
                                .fill(.yellow)
                                .frame(width: badgeSize, height: badgeSize)
                            Text("\(highScore)")
                                .font(isLarge ? .caption.bold() : .caption.bold())
                                .foregroundStyle(.black)
                        }
                        .offset(x: badgeOffset, y: -badgeOffset)
                    }
                    Spacer()
                }
            }
        }
    }
}

// MARK: - Game Play View
struct GamePlayView: View {
    let category: LevelCategory
    let level: Int
    @EnvironmentObject var appState: AppState
    @Environment(\.dismiss) var dismiss
    
    @State private var cards: [Card] = []
    @State private var currentIndex = 0
    @State private var score = 0
    @State private var showCompletion = false
    @State private var correctAnswers = 0
    
    var totalQuestions: Int {
        cards.filter { $0.type == .puzzle }.count
    }
    
    var body: some View {
        ZStack {
            LinearGradient(colors: [category.color, category.secondaryColor], 
                           startPoint: .topLeading, endPoint: .bottomTrailing)
            .ignoresSafeArea()
            
            if !cards.isEmpty {
                VStack {
                    HStack {
                        Button(action: { 
                            SoundManager.shared.playTap()
                            dismiss() 
                        }) {
                            Image(systemName: "chevron.left")
                                .font(.title2)
                                .foregroundColor(.white)
                                .padding()
                                .background(.white.opacity(0.2))
                                .clipShape(Circle())
                        }
                        
                        Spacer()
                        
                        HStack {
                            Image(systemName: "star.fill")
                                .foregroundStyle(.yellow)
                            Text("\(appState.totalScore + score)")
                                .font(.title3.bold())
                                .foregroundStyle(.white)
                        }
                        .padding(10)
                        .background(.white.opacity(0.2))
                        .clipShape(Capsule())
                    }
                    .padding()
                    
                    HStack {
                        ForEach(0..<cards.count, id: \.self) { index in
                            Circle()
                                .fill(index == currentIndex ? .white : .white.opacity(0.4))
                                .frame(width: 10, height: 10)
                        }
                    }
                    .padding(.bottom)
                    
                    TabView(selection: $currentIndex) {
                        ForEach(0..<cards.count, id: \.self) { index in
                            CardContainerView(
                                card: cards[index],
                                categoryId: category.id,
                                categoryColor: category.color,
                                onCorrect: {
                                    SoundManager.shared.playCorrect()
                                    score += 10
                                    correctAnswers += 1
                                },
                                onNext: {
                                    SoundManager.shared.playTap()
                                    handleNext()
                                }
                            )
                            .tag(index)
                        }
                    }
                    .tabViewStyle(.page(indexDisplayMode: .never))
                }
            }
            
            if showCompletion {
                CompletionView(
                    score: score,
                    totalPossible: totalQuestions * 10,
                    rating: PerformanceRating.from(score: score, totalPossible: totalQuestions * 10),
                    categoryColor: category.color,
                    onContinue: {
                        SoundManager.shared.playTap()
                        dismiss()
                    }
                )
                .environmentObject(appState)
                .onAppear {
                    SoundManager.shared.playWinningScreen()
                }
            }
        }
        .navigationBarHidden(true)
        .onAppear {
            loadCards()
        }
    }
    
    func loadCards() {
        var allCards = GameData.getCards(for: category.id, level: level)
        if appState.isSimpleMode {
            allCards = allCards.filter { $0.puzzleType != .choice }
        }
        self.cards = allCards
        self.currentIndex = 0
        self.score = 0
        self.correctAnswers = 0
    }
    
    func handleNext() {
        if currentIndex < cards.count - 1 {
            withAnimation {
                currentIndex += 1
            }
        } else {
            appState.saveHighScore(categoryId: category.id, level: level, score: score)
            
            let nextLevel = level + 1
            if category.levels.contains(nextLevel) {
                appState.unlockLevel(categoryId: category.id, level: nextLevel)
            }
            
            withAnimation {
                showCompletion = true
            }
        }
    }
}

// MARK: - Card Container View
struct CardContainerView: View {
    let card: Card
    let categoryId: String
    let categoryColor: Color
    let onCorrect: () -> Void
    let onNext: () -> Void
    
    @EnvironmentObject var appState: AppState
    @State private var isCompleted = false
    
    var body: some View {
        VStack {
            Spacer()
            
            VStack(spacing: 20) {
                if card.type == .learn {
                    LearningCardContentView(visual: card.visual, categoryId: categoryId, scenarioColor: categoryColor)
                        .frame(height: 400)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .padding()
                    
                    if let question = card.question {
                        if !appState.isSimpleMode {
                            Text(question)
                                .font(.title2.bold())
                                .multilineTextAlignment(.center)
                                .padding()
                        }
                    }
                    
                    Button(action: onNext) {
                        Image(systemName: "arrow.right")
                            .font(.title)
                            .foregroundStyle(.white)
                            .frame(width: 60, height: 60)
                            .background(categoryColor)
                            .clipShape(Circle())
                    }
                    
                } else {
                    if let puzzleType = card.puzzleType {
                        if card.visual == .racing_puzzle {
                            RacingGameView(onComplete: { finalDistance in
                                onCorrect()
                                onNext()
                            })
                            .frame(height: 550)
                            .cornerRadius(20)
                        } else if puzzleType == .pathfinding {
                            PathfindingPuzzleView(
                                categoryId: categoryId,
                                categoryColor: categoryColor,
                                onCorrect: {
                                    if !isCompleted {
                                        onCorrect()
                                        isCompleted = true
                                    }
                                },
                                onComplete: onNext
                            )
                            .frame(height: 500)
                            .padding()
                            .background(.white)
                            .cornerRadius(30)
                            .shadow(radius: 20)
                            .padding(30)
                        } else {
                            PuzzleContainerView(
                                puzzleType: puzzleType,
                                visual: card.visual,
                                categoryColor: categoryColor,
                                question: card.question,
                                options: card.options,
                                correctAnswer: card.correctAnswer,
                                onCorrect: {
                                    if !isCompleted {
                                        onCorrect()
                                        isCompleted = true
                                    }
                                },
                                onComplete: onNext
                            )
                            .frame(height: 500)
                        }
                    }
                }
            }
            .padding()
            .background(.white)
            .cornerRadius(30)
            .shadow(radius: 20)
            .padding(30)
            
            Spacer()
        }
    }
}

// MARK: - Learning Card Content
struct LearningCardContentView: View {
    let visual: CardVisual
    let categoryId: String
    let scenarioColor: Color
    
    @State private var carLeftToRightOffset: CGFloat = -100
    @State private var carRightToLeftOffset: CGFloat = 500
    @State private var ballOffset: CGFloat = 100
    @State private var personPosition: CGFloat = 100
    
    var timeOfDayGradient: LinearGradient {
        LinearGradient(colors: [
            Color(red: 1.0, green: 0.9, blue: 0.7),
            Color(red: 0.53, green: 0.81, blue: 0.92)
        ], startPoint: .top, endPoint: .bottom)
    }
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                WindowBorderView()
                
                timeOfDayGradient
                    .ignoresSafeArea()
                
                VStack {
                    HStack {
                        Image(systemName: "sun.max.fill")
                            .font(.system(size: 40))
                            .foregroundColor(.white.opacity(0.6))
                            .padding(30)
                        Spacer()
                    }
                    Spacer()
                }
                
                Group {
                    switch visual {
                    case .pedestrianCarsMoving_learn:
                        ZStack {
                            Rectangle()
                                .fill(Color.gray.opacity(0.6))
                                .frame(height: 150)
                                .position(x: geometry.size.width / 2, y: geometry.size.height * 0.6)
                            
                            Image(systemName: "car.fill")
                                .font(.system(size: 60))
                                .foregroundColor(.blue)
                                .position(x: carLeftToRightOffset, y: geometry.size.height * 0.58)
                            
                            Image(systemName: "car.fill")
                                .font(.system(size: 60))
                                .foregroundColor(.red)
                                .position(x: carRightToLeftOffset, y: geometry.size.height * 0.62)
                        }
                        .onAppear {
                            withAnimation(Animation.linear(duration: 3).repeatForever(autoreverses: false)) {
                                carLeftToRightOffset = geometry.size.width + 100
                            }
                            withAnimation(Animation.linear(duration: 2.5).repeatForever(autoreverses: false)) {
                                carRightToLeftOffset = -100
                            }
                        }
                        
                    case .pedestrianBallRolling_learn:
                        ZStack {
                            Rectangle()
                                .fill(Color.gray.opacity(0.6))
                                .frame(height: 150)
                                .position(x: geometry.size.width / 2, y: geometry.size.height * 0.6)
                            
                            Image(systemName: "figure.child")
                                .font(.system(size: 60))
                                .foregroundColor(.yellow)
                                .position(x: 100, y: geometry.size.height * 0.4)
                            
                            Circle()
                                .fill(Color.orange)
                                .frame(width: 40, height: 40)
                                .position(x: ballOffset, y: geometry.size.height * 0.6)
                        }
                        .onAppear {
                            withAnimation(Animation.easeIn(duration: 2)) {
                                ballOffset = geometry.size.width / 2
                            }
                        }
                        
                    case .pedestrianGreenLight_safe, .trafficPersonOnZebra_safe:
                        ZStack {
                            Rectangle()
                                .fill(Color.gray.opacity(0.6))
                                .frame(height: 150)
                                .position(x: geometry.size.width / 2, y: geometry.size.height * 0.6)
                            
                            HStack(spacing: 15) {
                                ForEach(0..<5) { _ in
                                    Rectangle()
                                        .fill(Color.white)
                                        .frame(width: 40, height: 80)
                                }
                            }
                            .position(x: geometry.size.width / 2, y: geometry.size.height * 0.6)
                            
                            VStack(spacing: 15) {
                                Circle()
                                    .fill(Color.gray.opacity(0.3))
                                    .frame(width: 50, height: 50)
                                Circle()
                                    .fill(Color.gray.opacity(0.3))
                                    .frame(width: 50, height: 50)
                                Circle()
                                    .fill(Color.green)
                                    .frame(width: 50, height: 50)
                                    .shadow(color: .green, radius: 10)
                            }
                            .padding()
                            .background(Color.black.opacity(0.7))
                            .cornerRadius(15)
                            .position(x: 80, y: geometry.size.height * 0.4)
                            
                            Image(systemName: "figure.walk")
                                .font(.system(size: 70))
                                .foregroundColor(.green)
                                .position(x: geometry.size.width / 2, y: geometry.size.height * 0.6)
                        }
                        
                    case .cyclistOnRoad_learn:
                        ZStack {
                            Rectangle()
                                .fill(Color.gray.opacity(0.6))
                                .frame(height: 150)
                                .position(x: geometry.size.width / 2, y: geometry.size.height * 0.6)
                            
                            Image(systemName: "bicycle")
                                .font(.system(size: 80))
                                .foregroundColor(.green)
                                .position(x: geometry.size.width / 2, y: geometry.size.height * 0.6)
                        }
                        
                    case .cyclistWearingHelmet_safe:
                        ZStack {
                            Rectangle()
                                .fill(Color.gray.opacity(0.6))
                                .frame(height: 150)
                                .position(x: geometry.size.width / 2, y: geometry.size.height * 0.6)
                            
                            VStack(spacing: 0) {
                                Text("🪖")
                                    .font(.system(size: 50))
                                Image(systemName: "bicycle")
                                    .font(.system(size: 80))
                                    .foregroundColor(.green)
                            }
                            .position(x: geometry.size.width / 2, y: geometry.size.height * 0.6)
                        }
                        
                    case .pedestrianDontCross_learn:
                        ZStack {
                            Rectangle()
                                .fill(Color.gray.opacity(0.6))
                                .frame(height: 150)
                                .position(x: geometry.size.width / 2, y: geometry.size.height * 0.6)
                            
                            Image("Pedestrian")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 150, height: 150)
                                .position(x: geometry.size.width * 0.2, y: geometry.size.height * 0.3)
                            
                            Image(systemName: "figure.walk")
                                .font(.system(size: 70))
                                .foregroundColor(.red)
                                .position(x: geometry.size.width * 0.5, y: geometry.size.height * 0.6)
                        }
                        
                    case .cyclistTurnLeft_learn:
                        ZStack {
                            Rectangle()
                                .fill(Color.gray.opacity(0.6))
                                .frame(height: 150)
                                .position(x: geometry.size.width / 2, y: geometry.size.height * 0.6)
                            
                            Image("Cyclist")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 150, height: 150)
                                .position(x: geometry.size.width * 0.2, y: geometry.size.height * 0.3)
                            
                            Image(systemName: "bicycle")
                                .font(.system(size: 80))
                                .foregroundColor(.green)
                                .rotationEffect(.degrees(-20))
                                .position(x: geometry.size.width * 0.5, y: geometry.size.height * 0.6)
                        }
                        
                    case .driverInCar_learn:
                        ZStack {
                            Rectangle()
                                .fill(Color.orange.opacity(0.8))
                                .frame(width: geometry.size.width * 0.6, height: geometry.size.height * 0.5)
                                .cornerRadius(20)
                                .position(x: geometry.size.width * 0.7, y: geometry.size.height / 2)
                            
                            Image(systemName: "person.fill")
                                .font(.system(size: 100))
                                .foregroundColor(.white.opacity(0.9))
                                .position(x: geometry.size.width * 0.5, y: geometry.size.height / 2)
                        }
                        
                    case .driverWithSeatbelt_safe:
                        ZStack {
                            Rectangle()
                                .fill(Color.orange.opacity(0.8))
                                .frame(width: geometry.size.width * 0.6, height: geometry.size.height * 0.5)
                                .cornerRadius(20)
                                .position(x: geometry.size.width * 0.7, y: geometry.size.height / 2)
                            
                            ZStack {
                                Image(systemName: "person.fill")
                                    .font(.system(size: 100))
                                    .foregroundColor(.white.opacity(0.9))
                                
                                Capsule()
                                    .fill(Color.green)
                                    .frame(width: 8, height: 140)
                                    .rotationEffect(.degrees(-45))
                            }
                            .position(x: geometry.size.width * 0.5, y: geometry.size.height / 2)
                        }
                        
                    case .driverStraightNoUTurn_learn:
                        ZStack {
                            Rectangle()
                                .fill(Color.gray.opacity(0.6))
                                .frame(height: 150)
                                .position(x: geometry.size.width / 2, y: geometry.size.height * 0.6)
                            
                            Image("Driver")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 150, height: 150)
                                .position(x: geometry.size.width * 0.2, y: geometry.size.height * 0.3)
                            
                            Image(systemName: "car.fill")
                                .font(.system(size: 70))
                                .foregroundColor(.orange)
                                .position(x: geometry.size.width * 0.6, y: geometry.size.height * 0.6)
                            
                            Image(systemName: "arrow.up")
                                .font(.system(size: 40))
                                .foregroundColor(.white)
                                .position(x: geometry.size.width * 0.6, y: geometry.size.height * 0.45)
                        }
                        
                    case .trafficPersonOffZebra_learn:
                        ZStack {
                            Rectangle()
                                .fill(Color.gray.opacity(0.6))
                                .frame(height: 150)
                                .position(x: geometry.size.width / 2, y: geometry.size.height * 0.6)
                            
                            HStack(spacing: 15) {
                                ForEach(0..<5) { _ in
                                    Rectangle()
                                        .fill(Color.white)
                                        .frame(width: 40, height: 80)
                                }
                            }
                            .position(x: geometry.size.width / 2, y: geometry.size.height * 0.6)
                            
                            Image(systemName: "figure.walk")
                                .font(.system(size: 70))
                                .foregroundColor(.red)
                                .position(x: geometry.size.width * 0.3, y: geometry.size.height * 0.6)
                        }
                        
                    case .trafficLevel2Learn:
                        ZStack {
                            Rectangle()
                                .fill(Color.gray.opacity(0.6))
                                .frame(height: 150)
                                .position(x: geometry.size.width / 2, y: geometry.size.height * 0.6)
                            
                            HStack(spacing: 20) {
                                TrafficLightView(color: .red, isBlinking: true)
                                    .frame(width: 60, height: 150)
                                TrafficLightView(color: .yellow, isBlinking: true)
                                    .frame(width: 60, height: 150)
                                TrafficLightView(color: .green, isBlinking: true)
                                    .frame(width: 60, height: 150)
                            }
                            .position(x: geometry.size.width / 2, y: geometry.size.height * 0.5)
                        }
                        
                    case .pedestrianLevel3Learn, .cyclistLevel3Learn, .driverLevel3Learn, .trafficLevel3Learn:
                        ZStack {
                            Rectangle()
                                .fill(Color.gray.opacity(0.6))
                                .frame(height: 150)
                                .position(x: geometry.size.width / 2, y: geometry.size.height * 0.6)
                            
                            Rectangle()
                                .fill(Color.black.opacity(0.3))
                                .frame(width: 10, height: geometry.size.height)
                                .position(x: geometry.size.width / 2, y: geometry.size.height / 2)
                            
                            Rectangle()
                                .fill(Color.black.opacity(0.3))
                                .frame(width: geometry.size.width, height: 10)
                                .position(x: geometry.size.width / 2, y: geometry.size.height * 0.6)
                            
                            VStack(spacing: 5) {
                                Circle()
                                    .fill(Color.red)
                                    .frame(width: 20, height: 20)
                                Circle()
                                    .fill(Color.yellow)
                                    .frame(width: 20, height: 20)
                                Circle()
                                    .fill(Color.green)
                                    .frame(width: 20, height: 20)
                            }
                            .position(x: geometry.size.width * 0.7, y: geometry.size.height * 0.4)
                            
                            Image(systemName: categoryIcon)
                                .font(.system(size: 60))
                                .foregroundColor(scenarioColor)
                                .position(x: geometry.size.width / 2, y: geometry.size.height * 0.6)
                        }
                        
                    default:
                        EmptyView()
                    }
                }
            }
        }
    }
    
    var categoryIcon: String {
        switch categoryId {
        case "pedestrian": return "figure.walk"
        case "cyclist": return "bicycle"
        case "driver": return "car.fill"
        case "traffic": return "exclamationmark.triangle.fill"
        default: return "questionmark"
        }
    }
}

// MARK: - Window Border View
struct WindowBorderView: View {
    var body: some View {
        ZStack {
            Color.black
            
            VStack {
                HStack {
                    Image(systemName: "circle.fill")
                        .font(.system(size: 12))
                        .foregroundColor(.white.opacity(0.8))
                        .padding(20)
                    Spacer()
                    Image(systemName: "circle.fill")
                        .font(.system(size: 12))
                        .foregroundColor(.white.opacity(0.8))
                        .padding(20)
                }
                Spacer()
                HStack {
                    Image(systemName: "circle.fill")
                        .font(.system(size: 12))
                        .foregroundColor(.white.opacity(0.8))
                        .padding(20)
                    Spacer()
                    Image(systemName: "circle.fill")
                        .font(.system(size: 12))
                        .foregroundColor(.white.opacity(0.8))
                        .padding(20)
                }
            }
            
            VStack {
                Rectangle()
                    .fill(Color.white.opacity(0.1))
                    .frame(height: 2)
                    .padding(.horizontal, 20)
                Spacer()
                Rectangle()
                    .fill(Color.white.opacity(0.1))
                    .frame(height: 2)
                    .padding(.horizontal, 20)
            }
            
            HStack {
                Rectangle()
                    .fill(Color.white.opacity(0.1))
                    .frame(width: 2)
                    .padding(.vertical, 40)
                Spacer()
                Rectangle()
                    .fill(Color.white.opacity(0.1))
                    .frame(width: 2)
                    .padding(.vertical, 40)
            }
        }
        .ignoresSafeArea()
    }
}

// MARK: - Puzzle Container View
struct PuzzleContainerView: View {
    let puzzleType: PuzzleType
    let visual: CardVisual
    let categoryColor: Color
    let question: String?
    let options: [String]?
    let correctAnswer: String?
    let onCorrect: () -> Void
    let onComplete: () -> Void
    
    @State private var borderGlowColor: Color = .clear
    @State private var showBorderGlow = false
    @State private var message: String = ""
    @EnvironmentObject var appState: AppState 
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                WindowBorderView()
                
                Group {
                    switch visual {
                    case .pedestrianRedLight_puzzle:
                        RedLightCrossingPuzzleView(
                            geometry: geometry,
                            onStop: {
                                onCorrect()
                                borderGlowColor = .green
                                showBorderGlow = true
                                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                                    showBorderGlow = false
                                    onComplete()
                                }
                            },
                            onWalk: {
                                SoundManager.shared.playError()
                                borderGlowColor = .red
                                showBorderGlow = true
                                message = "Try Again!"
                                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                                    showBorderGlow = false
                                    message = ""
                                }
                            }
                        )
                        
                    case .cyclistHelmetDrag_puzzle, .cyclistLevel3Puzzle2:
                        CyclistHelmetDragPuzzleView(
                            geometry: geometry,
                            onHelmetPlaced: {
                                onCorrect()
                                borderGlowColor = .green
                                showBorderGlow = true
                                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                                    showBorderGlow = false
                                    onComplete()
                                }
                            }
                        )
                        
                    case .driverSeatbeltDrag_puzzle:
                        DriverSeatbeltDragPuzzleView(
                            geometry: geometry,
                            onSeatbeltConnected: {
                                onCorrect()
                                borderGlowColor = .green
                                showBorderGlow = true
                                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                                    showBorderGlow = false
                                    onComplete()
                                }
                            }
                        )
                        
                    case .trafficDragToZebra_puzzle, .trafficLevel2Puzzle1:
                        if visual == .trafficLevel2Puzzle1 {
                            TrafficLightPatternPuzzleView(
                                geometry: geometry,
                                onCorrect: {
                                    onCorrect()
                                    borderGlowColor = .green
                                    showBorderGlow = true
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                                        showBorderGlow = false
                                        onComplete()
                                    }
                                },
                                onComplete: onComplete
                            )
                        } else {
                            TrafficZebraCrossingPuzzleView(
                                geometry: geometry,
                                onCorrectPlacement: {
                                    onCorrect()
                                    borderGlowColor = .green
                                    showBorderGlow = true
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                                        showBorderGlow = false
                                        onComplete()
                                    }
                                },
                                onWrongPlacement: {
                                    SoundManager.shared.playError()
                                    borderGlowColor = .red
                                    showBorderGlow = true
                                    message = "Place on zebra crossing!"
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                                        showBorderGlow = false
                                        message = ""
                                    }
                                }
                            )
                        }
                        
                    case .pedestrianTouchSign_interactive:
                        TouchSignTurnOffView(
                            geometry: geometry,
                            signType: .dontWalk,
                            onSignTouched: {
                                onCorrect()
                                borderGlowColor = .green
                                showBorderGlow = true
                                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                                    showBorderGlow = false
                                    onComplete()
                                }
                            },
                            imageName: "Pedestrian"
                        )
                        
                    case .cyclistTouchTurnSign_interactive:
                        TouchSignTurnOffView(
                            geometry: geometry,
                            signType: .turnLeft,
                            onSignTouched: {
                                onCorrect()
                                borderGlowColor = .green
                                showBorderGlow = true
                                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                                    showBorderGlow = false
                                    onComplete()
                                }
                            },
                            imageName: "Cyclist"
                        )
                        
                    case .driverTouchNoUTurn_interactive:
                        TouchSignTurnOffView(
                            geometry: geometry,
                            signType: .noUTurn,
                            onSignTouched: {
                                onCorrect()
                                borderGlowColor = .green
                                showBorderGlow = true
                                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                                    showBorderGlow = false
                                    onComplete()
                                }
                            },
                            imageName: "Driver"
                        )
                        
                    case .pedestrianSignJigsaw_puzzle, .cyclistTurnSignJigsaw_puzzle, .driverNoUTurnJigsaw_puzzle:
                        JigsawPuzzleView(
                            geometry: geometry,
                            signType: getSignType(from: visual),
                            scenarioColor: categoryColor,
                            onPuzzleComplete: {
                                onCorrect()
                                borderGlowColor = .green
                                showBorderGlow = true
                                DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                                    showBorderGlow = false
                                    onComplete()
                                }
                            },
                            imageName: visual == .pedestrianSignJigsaw_puzzle ? "Pedestrian" : 
                                visual == .cyclistTurnSignJigsaw_puzzle ? "Cyclist" : 
                                visual == .driverNoUTurnJigsaw_puzzle ? "Driver" : nil
                        )
                        
                    case .trafficLevel3Puzzle2:
                        FindSafetyFeaturesView(
                            geometry: geometry,
                            onCorrect: {
                                onCorrect()
                                borderGlowColor = .green
                                showBorderGlow = true
                                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                                    showBorderGlow = false
                                    onComplete()
                                }
                            }
                        )
                        
                    default:
                        if puzzleType == .choice, let options = options, let correctAnswer = correctAnswer {
                            ChoicePuzzleContentView(
                                question: question,
                                options: options,
                                correctAnswer: correctAnswer,
                                categoryColor: categoryColor,
                                onCorrect: {
                                    onCorrect()
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                                        onComplete()
                                    }
                                },
                                message: $message
                            )
                        } else {
                            Text("Puzzle coming soon")
                                .foregroundColor(.white)
                        }
                    }
                }
                
                if showBorderGlow {
                    Rectangle()
                        .stroke(borderGlowColor, lineWidth: 8)
                        .shadow(color: borderGlowColor, radius: 20)
                        .ignoresSafeArea()
                        .animation(.easeInOut(duration: 0.3), value: borderGlowColor)
                        .allowsHitTesting(false)
                }
                
                if !message.isEmpty {
                    VStack {
                        Spacer()
                        Text(message)
                            .font(.title2)
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.black.opacity(0.7))
                            .cornerRadius(15)
                            .padding(.bottom, 50)
                    }
                }
            }
        }
    }
    
    func getSignType(from visual: CardVisual) -> SignType {
        switch visual {
        case .pedestrianSignJigsaw_puzzle:
            return .dontWalk
        case .cyclistTurnSignJigsaw_puzzle:
            return .turnLeft
        case .driverNoUTurnJigsaw_puzzle:
            return .noUTurn
        default:
            return .dontWalk
        }
    }
}

// MARK: - Traffic Light Pattern Puzzle View
struct TrafficLightPatternPuzzleView: View {
    let geometry: GeometryProxy
    let onCorrect: () -> Void
    let onComplete: () -> Void
    @EnvironmentObject var appState: AppState
    
    @State private var currentPattern: [TrafficLightColor] = [.red, .yellow, .green]
    @State private var selectedPattern: [TrafficLightColor] = []
    @State private var blinkingLight: Int? = nil
    @State private var showSuccess = false
    @State private var patternIndex = 0
    
    let correctSequence: [TrafficLightColor] = [.red, .yellow, .green]
    
    var body: some View {
        ZStack {
            LinearGradient(colors: [Color.blue.opacity(0.4), Color.purple.opacity(0.4), Color.pink.opacity(0.4)], 
                           startPoint: .topLeading, endPoint: .bottomTrailing)
            .ignoresSafeArea()
            
            Image(systemName: "sun.max.fill")
                .font(.system(size: 60))
                .foregroundColor(.yellow.opacity(0.3))
                .position(x: 50, y: 50)
            
            VStack(spacing: 40) {
                HStack {
                    if !appState.isSimpleMode {
                        Text("What comes next?")
                            .font(.title.bold())
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.purple.opacity(0.5))
                            .cornerRadius(15)
                    }
                    
                    Image(systemName: "questionmark.circle.fill")
                        .font(.system(size: 40))
                        .foregroundColor(.yellow)
                }
                .padding(.top, 80)
                
                HStack(spacing: 20) {
                    ForEach(0..<3, id: \.self) { index in
                        if index < currentPattern.count {
                            TrafficLightView(
                                color: currentPattern[index],
                                isBlinking: blinkingLight == index
                            )
                            .frame(width: 80, height: 200)
                            .onTapGesture {
                                startBlinking()
                            }
                        }
                    }
                }
                
                VStack(spacing: 20) {
                    if !appState.isSimpleMode {
                        Text("Tap in correct order:")
                            .font(.headline)
                            .foregroundColor(.white)
                    }
                    
                    HStack(spacing: 15) {
                        ForEach(0..<3, id: \.self) { index in
                            Circle()
                                .fill(colorForIndex(index))
                                .frame(width: 60, height: 60)
                                .overlay(
                                    Circle()
                                        .stroke(Color.white, lineWidth: 3)
                                )
                                .shadow(radius: 5)
                                .scaleEffect(selectedPattern.count > index ? 1.1 : 1.0)
                                .onTapGesture {
                                    selectColor(index: index)
                                }
                        }
                    }
                }
                
                if showSuccess {
                    HStack {
                        if !appState.isSimpleMode {
                            Text("🎉 Correct! Well done! 🎉")
                                .font(.title2.bold())
                                .foregroundColor(.yellow)
                        } else {
                            Image(systemName: "checkmark.circle.fill")
                                .font(.system(size: 60))
                                .foregroundColor(.green)
                        }
                    }
                    .padding()
                    .background(Color.green.opacity(0.7))
                    .cornerRadius(15)
                    .transition(.scale.combined(with: .opacity))
                }
            }
        }
        .onAppear {
            startBlinking()
        }
    }
    
    func colorForIndex(_ index: Int) -> Color {
        switch index {
        case 0: return .red
        case 1: return .yellow
        case 2: return .green
        default: return .gray
        }
    }
    
    func selectColor(index: Int) {
        guard !showSuccess else { return }
        
        let expectedIndex = selectedPattern.count
        if expectedIndex < correctSequence.count {
            let expectedColor = correctSequence[expectedIndex]
            let selectedColor: TrafficLightColor = index == 0 ? .red : (index == 1 ? .yellow : .green)
            
            if selectedColor == expectedColor {
                selectedPattern.append(selectedColor)
                
                if selectedPattern.count == correctSequence.count {
                    withAnimation {
                        showSuccess = true
                    }
                    onCorrect()
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                        onComplete()
                    }
                }
            } else {
                withAnimation {
                    selectedPattern = []
                }
            }
        }
    }
    
    func startBlinking() {
        var delay = 0.0
        for i in 0..<correctSequence.count {
            DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
                withAnimation(.easeInOut(duration: 0.3).repeatCount(2, autoreverses: true)) {
                    blinkingLight = i
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
                    blinkingLight = nil
                }
            }
            delay += 1.0
        }
    }
}

// MARK: - Traffic Light View
struct TrafficLightView: View {
    let color: TrafficLightColor
    let isBlinking: Bool
    
    var body: some View {
        VStack(spacing: 8) {
            Circle()
                .fill(color == .red ? Color.red : Color.gray.opacity(0.3))
                .frame(width: 50, height: 50)
                .overlay(
                    Circle()
                        .stroke(Color.white, lineWidth: 2)
                )
                .shadow(color: color == .red && isBlinking ? .red : .clear, radius: 10)
                .scaleEffect(color == .red && isBlinking ? 1.1 : 1.0)
            
            Circle()
                .fill(color == .yellow ? Color.yellow : Color.gray.opacity(0.3))
                .frame(width: 50, height: 50)
                .overlay(
                    Circle()
                        .stroke(Color.white, lineWidth: 2)
                )
                .shadow(color: color == .yellow && isBlinking ? .yellow : .clear, radius: 10)
                .scaleEffect(color == .yellow && isBlinking ? 1.1 : 1.0)
            
            Circle()
                .fill(color == .green ? Color.green : Color.gray.opacity(0.3))
                .frame(width: 50, height: 50)
                .overlay(
                    Circle()
                        .stroke(Color.white, lineWidth: 2)
                )
                .shadow(color: color == .green && isBlinking ? .green : .clear, radius: 10)
                .scaleEffect(color == .green && isBlinking ? 1.1 : 1.0)
        }
        .padding()
        .background(Color.black.opacity(0.7))
        .cornerRadius(20)
    }
}

// MARK: - Find Safety Features View
struct FindSafetyFeaturesView: View {
    let geometry: GeometryProxy
    let onCorrect: () -> Void
    @EnvironmentObject var appState: AppState
    
    @State private var foundFeatures: Set<String> = []
    @State private var showMessage = false
    
    let features = [
        (id: "zebra", name: "Zebra Crossing", position: CGPoint(x: 200, y: 300)),
        (id: "light", name: "Traffic Light", position: CGPoint(x: 100, y: 150)),
        (id: "sign", name: "Warning Sign", position: CGPoint(x: 300, y: 200))
    ]
    
    var body: some View {
        ZStack {
            LinearGradient(colors: [.blue.opacity(0.3), .green.opacity(0.3)], 
                           startPoint: .topLeading, endPoint: .bottomTrailing)
            .ignoresSafeArea()
            
            Rectangle()
                .fill(Color.gray.opacity(0.6))
                .frame(height: 150)
                .position(x: geometry.size.width / 2, y: geometry.size.height * 0.6)
            
            HStack(spacing: 15) {
                ForEach(0..<5) { _ in
                    Rectangle()
                        .fill(Color.white)
                        .frame(width: 40, height: 80)
                }
            }
            .position(x: 200, y: 300)
            .onTapGesture {
                if !foundFeatures.contains("zebra") {
                    foundFeatures.insert("zebra")
                    checkCompletion()
                }
            }
            
            VStack(spacing: 5) {
                Circle()
                    .fill(Color.red)
                    .frame(width: 30, height: 30)
                Circle()
                    .fill(Color.yellow)
                    .frame(width: 30, height: 30)
                Circle()
                    .fill(Color.green)
                    .frame(width: 30, height: 30)
            }
            .position(x: 100, y: 150)
            .onTapGesture {
                if !foundFeatures.contains("light") {
                    foundFeatures.insert("light")
                    checkCompletion()
                }
            }
            
            ZStack {
                RoundedRectangle(cornerRadius: 5)
                    .fill(Color.yellow)
                    .frame(width: 50, height: 50)
                Image(systemName: "exclamationmark.triangle.fill")
                    .foregroundColor(.black)
            }
            .position(x: 300, y: 200)
            .onTapGesture {
                if !foundFeatures.contains("sign") {
                    foundFeatures.insert("sign")
                    checkCompletion()
                }
            }
            
            VStack {
                if !appState.isSimpleMode {
                    Text("Found: \(foundFeatures.count)/\(features.count)")
                        .font(.title2)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.black.opacity(0.7))
                        .cornerRadius(15)
                } else {
                    HStack {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundColor(.green)
                        Text("\(foundFeatures.count)/\(features.count)")
                            .font(.title2)
                            .foregroundColor(.white)
                    }
                    .padding()
                    .background(Color.black.opacity(0.7))
                    .cornerRadius(15)
                }
                Spacer()
            }
            .padding(.top, 100)
        }
    }
    
    func checkCompletion() {
        if foundFeatures.count == features.count {
            onCorrect()
        }
    }
}

// MARK: - Red Light Crossing Puzzle
struct RedLightCrossingPuzzleView: View {
    let geometry: GeometryProxy
    let onStop: () -> Void
    let onWalk: () -> Void
    @EnvironmentObject var appState: AppState
    
    @State private var carLeftToRightOffset: CGFloat
    @State private var carRightToLeftOffset: CGFloat
    
    init(geometry: GeometryProxy, onStop: @escaping () -> Void, onWalk: @escaping () -> Void) {
        self.geometry = geometry
        self.onStop = onStop
        self.onWalk = onWalk
        _carLeftToRightOffset = State(initialValue: -100)
        _carRightToLeftOffset = State(initialValue: geometry.size.width + 100)
    }
    
    var body: some View {
        ZStack {
            LinearGradient(colors: [.blue.opacity(0.4), .purple.opacity(0.4)], 
                           startPoint: .topLeading, endPoint: .bottomTrailing)
            .ignoresSafeArea()
            
            Rectangle()
                .fill(Color.gray.opacity(0.6))
                .frame(height: 150)
                .position(x: geometry.size.width / 2, y: geometry.size.height * 0.6)
            
            HStack(spacing: 15) {
                ForEach(0..<5) { _ in
                    Rectangle()
                        .fill(Color.white)
                        .frame(width: 40, height: 80)
                }
            }
            .position(x: geometry.size.width / 2, y: geometry.size.height * 0.6)
            
            VStack(spacing: 15) {
                Circle()
                    .fill(Color.red)
                    .frame(width: 50, height: 50)
                    .shadow(color: .red, radius: 10)
                Circle()
                    .fill(Color.gray.opacity(0.3))
                    .frame(width: 50, height: 50)
                Circle()
                    .fill(Color.gray.opacity(0.3))
                    .frame(width: 50, height: 50)
            }
            .padding()
            .background(Color.black.opacity(0.7))
            .cornerRadius(15)
            .position(x: 80, y: geometry.size.height * 0.4)
            
            Image(systemName: "car.fill")
                .font(.system(size: 60))
                .foregroundColor(.blue)
                .position(x: carLeftToRightOffset, y: geometry.size.height * 0.58)
            
            Image(systemName: "car.fill")
                .font(.system(size: 60))
                .foregroundColor(.red)
                .position(x: carRightToLeftOffset, y: geometry.size.height * 0.62)
            
            Image(systemName: "figure.child")
                .font(.system(size: 70))
                .foregroundColor(.yellow)
                .position(x: 150, y: geometry.size.height * 0.5)
            
            VStack(spacing: 40) {
                Spacer()
                
                HStack(spacing: 80) {
                    VStack(spacing: 10) {
                        ZStack {
                            Circle()
                                .fill(Color.red.opacity(0.8))
                                .frame(width: 100, height: 100)
                                .shadow(radius: 10)
                            
                            Image(systemName: "hand.raised.fill")
                                .font(.system(size: 50))
                                .foregroundColor(.white)
                        }
                        
                        Text("STOP")
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(.white)
                    }
                    .onTapGesture {
                        onStop()
                    }
                    
                    VStack(spacing: 10) {
                        ZStack {
                            Circle()
                                .fill(Color.green.opacity(0.8))
                                .frame(width: 100, height: 100)
                                .shadow(radius: 10)
                            
                            Image(systemName: "figure.walk")
                                .font(.system(size: 50))
                                .foregroundColor(.white)
                        }
                        
                        Text("WALK")
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(.white)
                    }
                    .onTapGesture {
                        onWalk()
                    }
                }
                .padding(.bottom, 60)
            }
        }
        .onAppear {
            withAnimation(Animation.linear(duration: 2).repeatForever(autoreverses: false)) {
                carLeftToRightOffset = geometry.size.width + 100
            }
            withAnimation(Animation.linear(duration: 1.8).repeatForever(autoreverses: false)) {
                carRightToLeftOffset = -100
            }
        }
    }
}

// MARK: - Cyclist Helmet Drag Puzzle
struct CyclistHelmetDragPuzzleView: View {
    let geometry: GeometryProxy
    let onHelmetPlaced: () -> Void
    @EnvironmentObject var appState: AppState
    
    @State private var helmetPosition: CGPoint
    @State private var currentHelmetPosition: CGPoint
    @State private var helmetPlaced = false
    
    var personHeadPosition: CGPoint {
        CGPoint(x: geometry.size.width / 2, y: geometry.size.height * 0.45)
    }
    let dropZoneRadius: CGFloat = 80
    
    init(geometry: GeometryProxy, onHelmetPlaced: @escaping () -> Void) {
        self.geometry = geometry
        self.onHelmetPlaced = onHelmetPlaced
        _helmetPosition = State(initialValue: CGPoint(x: geometry.size.width - 100, y: geometry.size.height * 0.7))
        _currentHelmetPosition = State(initialValue: CGPoint(x: geometry.size.width - 100, y: geometry.size.height * 0.7))
    }
    
    var body: some View {
        ZStack {
            LinearGradient(colors: [.green.opacity(0.3), .blue.opacity(0.3)], 
                           startPoint: .topLeading, endPoint: .bottomTrailing)
            .ignoresSafeArea()
            
            Rectangle()
                .fill(Color.gray.opacity(0.6))
                .frame(height: 150)
                .position(x: geometry.size.width / 2, y: geometry.size.height * 0.65)
            
            VStack(spacing: 5) {
                Circle()
                    .fill(Color.yellow)
                    .frame(width: 60, height: 60)
                    .overlay(
                        Circle()
                            .stroke(helmetPlaced ? Color.clear : Color.red.opacity(0.5), lineWidth: 3)
                    )
                
                Image(systemName: "person.fill")
                    .font(.system(size: 80))
                    .foregroundColor(.yellow)
            }
            .position(personHeadPosition)
            
            if !helmetPlaced {
                Text("🪖")
                    .font(.system(size: 60))
                    .position(currentHelmetPosition)
                    .gesture(
                        DragGesture()
                            .onChanged { value in
                                currentHelmetPosition = value.location
                            }
                            .onEnded { value in
                                let distance = sqrt(
                                    pow(value.location.x - personHeadPosition.x, 2) +
                                    pow(value.location.y - personHeadPosition.y, 2)
                                )
                                if distance < dropZoneRadius {
                                    helmetPlaced = true
                                    onHelmetPlaced()
                                } else {
                                    withAnimation {
                                        currentHelmetPosition = helmetPosition
                                    }
                                }
                            }
                    )
            } else {
                Text("🪖")
                    .font(.system(size: 60))
                    .position(CGPoint(x: personHeadPosition.x, y: personHeadPosition.y - 30))
            }
            
            if !helmetPlaced && !appState.isSimpleMode {
                VStack {
                    Spacer()
                    Text("Drag helmet to person's head")
                        .font(.system(size: 26, weight: .bold))
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.black.opacity(0.5))
                        .cornerRadius(15)
                        .padding(.bottom, 50)
                }
            }
        }
    }
}

// MARK: - Driver Seatbelt Drag Puzzle
struct DriverSeatbeltDragPuzzleView: View {
    let geometry: GeometryProxy
    let onSeatbeltConnected: () -> Void
    @EnvironmentObject var appState: AppState
    
    @State private var seatbeltStartPosition: CGPoint
    @State private var seatbeltEndPosition: CGPoint?
    @State private var seatbeltConnected = false
    @State private var isDragging = false
    @State private var currentDragPosition: CGPoint?
    
    var bucklePosition: CGPoint {
        CGPoint(x: geometry.size.width * 0.6, y: geometry.size.height * 0.55)
    }
    
    var shoulderPosition: CGPoint {
        CGPoint(x: geometry.size.width * 0.4, y: geometry.size.height * 0.35)
    }
    
    let dropZoneRadius: CGFloat = 60
    
    init(geometry: GeometryProxy, onSeatbeltConnected: @escaping () -> Void) {
        self.geometry = geometry
        self.onSeatbeltConnected = onSeatbeltConnected
        _seatbeltStartPosition = State(initialValue: CGPoint(x: geometry.size.width * 0.4, y: geometry.size.height * 0.35))
    }
    
    var body: some View {
        ZStack {
            LinearGradient(colors: [Color.blue.opacity(0.3), Color.purple.opacity(0.3)], 
                           startPoint: .topLeading, endPoint: .bottomTrailing)
            .ignoresSafeArea()
            
            RoundedRectangle(cornerRadius: 20)
                .fill(Color.orange.opacity(0.8))
                .frame(width: geometry.size.width * 0.6, height: geometry.size.height * 0.5)
                .overlay(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(Color.yellow, lineWidth: 2)
                )
                .position(x: geometry.size.width * 0.6, y: geometry.size.height / 2)
            
            VStack(spacing: -10) {
                Circle()
                    .fill(Color.yellow)
                    .frame(width: 40, height: 40)
                    .overlay(
                        Circle()
                            .stroke(Color.orange, lineWidth: 2)
                    )
                
                Image(systemName: "person.fill")
                    .font(.system(size: 80))
                    .foregroundColor(.white.opacity(0.9))
            }
            .position(x: geometry.size.width * 0.5, y: geometry.size.height / 2)
            
            ZStack {
                Circle()
                    .fill(Color.gray.opacity(0.8))
                    .frame(width: 40, height: 40)
                Circle()
                    .stroke(seatbeltConnected ? Color.green : Color.yellow, lineWidth: 3)
                    .frame(width: 40, height: 40)
                Image(systemName: "lock.fill")
                    .foregroundColor(.white)
                    .font(.system(size: 20))
            }
            .position(bucklePosition)
            
            if !seatbeltConnected {
                ZStack {
                    Circle()
                        .fill(Color.green.opacity(0.8))
                        .frame(width: 40, height: 40)
                        .shadow(radius: 5)
                    Image(systemName: "shield.fill")
                        .foregroundColor(.white)
                        .font(.system(size: 20))
                }
                .position(seatbeltStartPosition)
                .gesture(
                    DragGesture()
                        .onChanged { value in
                            isDragging = true
                            currentDragPosition = value.location
                        }
                        .onEnded { value in
                            isDragging = false
                            currentDragPosition = nil
                            
                            let distance = sqrt(
                                pow(value.location.x - bucklePosition.x, 2) +
                                pow(value.location.y - bucklePosition.y, 2)
                            )
                            
                            if distance < dropZoneRadius {
                                withAnimation(.spring()) {
                                    seatbeltEndPosition = bucklePosition
                                    seatbeltConnected = true
                                }
                                onSeatbeltConnected()
                            }
                        }
                )
                
                if isDragging, let dragPos = currentDragPosition {
                    Path { path in
                        path.move(to: shoulderPosition)
                        path.addLine(to: dragPos)
                    }
                    .stroke(Color.green, lineWidth: 6)
                }
            } else {
                Path { path in
                    path.move(to: shoulderPosition)
                    path.addLine(to: CGPoint(x: bucklePosition.x - 10, y: bucklePosition.y))
                }
                .stroke(Color.green, lineWidth: 8)
                
                Path { path in
                    path.move(to: shoulderPosition)
                    path.addLine(to: CGPoint(x: shoulderPosition.x + 20, y: shoulderPosition.y + 30))
                }
                .stroke(Color.green, lineWidth: 8)
            }
            
            if !seatbeltConnected && !appState.isSimpleMode {
                VStack {
                    Spacer()
                    Text("Drag seatbelt to buckle! 🚗")
                        .font(.system(size: 26, weight: .bold))
                        .foregroundColor(.white)
                        .padding()
                        .background(
                            LinearGradient(colors: [Color.green, Color.blue], 
                                           startPoint: .leading, endPoint: .trailing)
                        )
                        .cornerRadius(15)
                        .shadow(radius: 10)
                        .padding(.bottom, 50)
                }
            }
        }
    }
}

// MARK: - Traffic Zebra Crossing Drag Puzzle
struct TrafficZebraCrossingPuzzleView: View {
    let geometry: GeometryProxy
    let onCorrectPlacement: () -> Void
    let onWrongPlacement: () -> Void
    @EnvironmentObject var appState: AppState
    
    @State private var personPosition: CGPoint
    @State private var currentPersonPosition: CGPoint
    @State private var personPlacedCorrectly = false
    
    var zebraCrossingCenter: CGPoint {
        CGPoint(x: geometry.size.width / 2, y: geometry.size.height * 0.6)
    }
    let zebraCrossingWidth: CGFloat = 250
    let zebraCrossingHeight: CGFloat = 100
    
    init(geometry: GeometryProxy, onCorrectPlacement: @escaping () -> Void, onWrongPlacement: @escaping () -> Void) {
        self.geometry = geometry
        self.onCorrectPlacement = onCorrectPlacement
        self.onWrongPlacement = onWrongPlacement
        _personPosition = State(initialValue: CGPoint(x: geometry.size.width * 0.3, y: geometry.size.height * 0.6))
        _currentPersonPosition = State(initialValue: CGPoint(x: geometry.size.width * 0.3, y: geometry.size.height * 0.6))
    }
    
    var body: some View {
        ZStack {
            LinearGradient(colors: [.yellow.opacity(0.3), .orange.opacity(0.3)], 
                           startPoint: .topLeading, endPoint: .bottomTrailing)
            .ignoresSafeArea()
            
            Rectangle()
                .fill(Color.gray.opacity(0.6))
                .frame(height: 150)
                .position(x: geometry.size.width / 2, y: geometry.size.height * 0.6)
            
            HStack(spacing: 15) {
                ForEach(0..<5) { _ in
                    Rectangle()
                        .fill(Color.white)
                        .frame(width: 40, height: 80)
                }
            }
            .position(zebraCrossingCenter)
            
            Image(systemName: "figure.walk")
                .font(.system(size: 70))
                .foregroundColor(personPlacedCorrectly ? .green : .red)
                .position(currentPersonPosition)
                .gesture(
                    DragGesture()
                        .onChanged { value in
                            currentPersonPosition = value.location
                        }
                        .onEnded { value in
                            let isOnZebra = abs(value.location.x - zebraCrossingCenter.x) < zebraCrossingWidth / 2 &&
                            abs(value.location.y - zebraCrossingCenter.y) < zebraCrossingHeight / 2
                            
                            if isOnZebra {
                                currentPersonPosition = zebraCrossingCenter
                                personPlacedCorrectly = true
                                onCorrectPlacement()
                            } else {
                                onWrongPlacement()
                                withAnimation {
                                    currentPersonPosition = personPosition
                                }
                            }
                        }
                )
            
            if !personPlacedCorrectly && !appState.isSimpleMode {
                VStack {
                    Spacer()
                    Text("Drag person to zebra crossing")
                        .font(.system(size: 26, weight: .bold))
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.black.opacity(0.5))
                        .cornerRadius(15)
                        .padding(.bottom, 50)
                }
            }
        }
    }
}

// MARK: - Sign Type Enum
enum SignType {
    case dontWalk
    case turnLeft
    case noUTurn
}

// MARK: - Touch Sign Turn Off View
struct TouchSignTurnOffView: View {
    let geometry: GeometryProxy
    let signType: SignType
    let onSignTouched: () -> Void
    var imageName: String? = nil
    @EnvironmentObject var appState: AppState
    
    @State private var personStopped = false
    @State private var personPosition: CGFloat
    
    init(geometry: GeometryProxy, signType: SignType, onSignTouched: @escaping () -> Void, imageName: String? = nil) {
        self.geometry = geometry
        self.signType = signType
        self.onSignTouched = onSignTouched
        self.imageName = imageName
        
        switch signType {
        case .dontWalk:
            _personPosition = State(initialValue: geometry.size.width * 0.3)
        case .turnLeft, .noUTurn:
            _personPosition = State(initialValue: geometry.size.width * 0.5)
        }
    }
    
    var body: some View {
        ZStack {
            LinearGradient(colors: [.mint.opacity(0.3), .cyan.opacity(0.3)], 
                           startPoint: .topLeading, endPoint: .bottomTrailing)
            .ignoresSafeArea()
            
            Rectangle()
                .fill(Color.gray.opacity(0.6))
                .frame(height: 150)
                .position(x: geometry.size.width / 2, y: geometry.size.height * 0.6)
            
            Group {
                if let imageName = imageName {
                    Image(imageName)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 150, height: 150)
                        .position(x: geometry.size.width * 0.2, y: geometry.size.height * 0.3)
                        .scaleEffect(personStopped ? 1.2 : 1.0)
                        .onTapGesture {
                            withAnimation {
                                personStopped = true
                            }
                            onSignTouched()
                        }
                } else {
                    switch signType {
                    case .dontWalk:
                        ZStack {
                            RoundedRectangle(cornerRadius: 10)
                                .fill(Color.orange.opacity(0.9))
                                .frame(width: 100, height: 120)
                            
                            VStack(spacing: 5) {
                                Image(systemName: "hand.raised.fill")
                                    .font(.system(size: 50))
                                    .foregroundColor(.red)
                                
                                if !appState.isSimpleMode {
                                    Text("DON'T\nWALK")
                                        .font(.system(size: 14, weight: .bold))
                                        .foregroundColor(.red)
                                        .multilineTextAlignment(.center)
                                }
                            }
                        }
                        .position(x: geometry.size.width * 0.2, y: geometry.size.height * 0.3)
                        .scaleEffect(personStopped ? 1.2 : 1.0)
                        .onTapGesture {
                            withAnimation {
                                personStopped = true
                            }
                            onSignTouched()
                        }
                        
                    case .turnLeft:
                        ZStack {
                            RoundedRectangle(cornerRadius: 10)
                                .fill(Color.blue.opacity(0.9))
                                .frame(width: 100, height: 100)
                            
                            Image(systemName: "arrow.turn.up.left")
                                .font(.system(size: 50))
                                .foregroundColor(.white)
                        }
                        .position(x: geometry.size.width * 0.2, y: geometry.size.height * 0.3)
                        .scaleEffect(personStopped ? 1.2 : 1.0)
                        .onTapGesture {
                            withAnimation {
                                personStopped = true
                            }
                            onSignTouched()
                        }
                        
                    case .noUTurn:
                        ZStack {
                            Circle()
                                .fill(Color.white)
                                .frame(width: 100, height: 100)
                            Circle()
                                .stroke(Color.red, lineWidth: 8)
                                .frame(width: 100, height: 100)
                            
                            Image(systemName: "u.turn.left.fill")
                                .font(.system(size: 50))
                                .foregroundColor(.black)
                            
                            Rectangle()
                                .fill(Color.red)
                                .frame(width: 90, height: 8)
                                .rotationEffect(.degrees(45))
                        }
                        .position(x: geometry.size.width * 0.2, y: geometry.size.height * 0.3)
                        .scaleEffect(personStopped ? 1.2 : 1.0)
                        .onTapGesture {
                            withAnimation {
                                personStopped = true
                            }
                            onSignTouched()
                        }
                    }
                }
            }
            
            Group {
                if signType == .dontWalk {
                    Image(systemName: "figure.walk")
                        .font(.system(size: 70))
                        .foregroundColor(personStopped ? .green : .red)
                        .position(x: personPosition, y: geometry.size.height * 0.6)
                } else if signType == .turnLeft {
                    Image(systemName: "bicycle")
                        .font(.system(size: 80))
                        .foregroundColor(personStopped ? .green : .orange)
                        .rotationEffect(personStopped ? .degrees(0) : .degrees(-20))
                        .position(x: personPosition, y: geometry.size.height * 0.6)
                } else {
                    Image(systemName: "car.fill")
                        .font(.system(size: 70))
                        .foregroundColor(personStopped ? .green : .orange)
                        .position(x: personPosition, y: geometry.size.height * 0.6)
                }
            }
            
            if !personStopped && !appState.isSimpleMode {
                VStack {
                    Spacer()
                    Text("Touch the sign!")
                        .font(.system(size: 30, weight: .bold))
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.black.opacity(0.5))
                        .cornerRadius(15)
                        .padding(.bottom, 50)
                }
            }
        }
        .onAppear {
            if !personStopped && signType == .dontWalk {
                withAnimation(Animation.linear(duration: 3).repeatForever(autoreverses: false)) {
                    personPosition = geometry.size.width * 0.7
                }
            }
        }
    }
}

// MARK: - Jigsaw Piece Model
struct JigsawPiece: Identifiable, Equatable {
    let id = UUID()
    let correctIndex: Int
    var currentPosition: CGPoint
    var isPlaced: Bool = false
}

// MARK: - Jigsaw Puzzle View
struct JigsawPuzzleView: View {
    let geometry: GeometryProxy
    let signType: SignType
    let scenarioColor: Color
    let onPuzzleComplete: () -> Void
    var imageName: String? = nil
    @EnvironmentObject var appState: AppState
    
    @State private var pieces: [JigsawPiece] = []
    @State private var puzzleComplete = false
    
    let gridSize = 2
    let pieceSize: CGFloat = 80
    
    var puzzleCenter: CGPoint {
        CGPoint(x: geometry.size.width / 2, y: geometry.size.height * 0.45)
    }
    
    var computedPieceSize: CGFloat {
        let maxDimension = min(geometry.size.width, geometry.size.height) * 0.5
        return maxDimension / CGFloat(gridSize)
    }
    
    var body: some View {
        ZStack {
            LinearGradient(colors: [.purple.opacity(0.3), .pink.opacity(0.3)], 
                           startPoint: .topLeading, endPoint: .bottomTrailing)
            .ignoresSafeArea()
            
            VStack(spacing: 5) {
                ForEach(0..<gridSize, id: \.self) { row in
                    HStack(spacing: 5) {
                        ForEach(0..<gridSize, id: \.self) { col in
                            let index = row * gridSize + col
                            Rectangle()
                                .stroke(Color.white.opacity(0.5), lineWidth: 2)
                                .frame(width: computedPieceSize, height: computedPieceSize)
                                .background(Color.black.opacity(0.2))
                                .overlay(
                                    pieces.first(where: { $0.correctIndex == index && $0.isPlaced })
                                        .map { _ in
                                            signPieceView(for: index)
                                        }
                                )
                        }
                    }
                }
            }
            .position(puzzleCenter)
            
            ForEach(pieces.filter { !$0.isPlaced }) { piece in
                signPieceView(for: piece.correctIndex)
                    .frame(width: computedPieceSize, height: computedPieceSize)
                    .position(piece.currentPosition)
                    .gesture(
                        DragGesture()
                            .onChanged { value in
                                if let index = pieces.firstIndex(where: { $0.id == piece.id }) {
                                    pieces[index].currentPosition = value.location
                                }
                            }
                            .onEnded { value in
                                checkPiecePlacement(piece: piece, at: value.location)
                            }
                    )
            }
            
            if !puzzleComplete && !appState.isSimpleMode {
                VStack {
                    Spacer()
                    Text("Drag pieces to complete the sign")
                        .font(.system(size: 24, weight: .bold))
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.black.opacity(0.5))
                        .cornerRadius(15)
                        .padding(.bottom, 50)
                }
            }
        }
        .onAppear {
            initializePuzzle()
        }
    }
    
    func initializePuzzle() {
        pieces = []
        let totalPieces = gridSize * gridSize
        
        for i in 0..<totalPieces {
            let randomX = CGFloat.random(in: 100...(geometry.size.width - 100))
            let randomY = CGFloat.random(in: geometry.size.height * 0.65...geometry.size.height * 0.85)
            
            pieces.append(JigsawPiece(
                correctIndex: i,
                currentPosition: CGPoint(x: randomX, y: randomY)
            ))
        }
    }
    
    func checkPiecePlacement(piece: JigsawPiece, at location: CGPoint) {
        let row = piece.correctIndex / gridSize
        let col = piece.correctIndex % gridSize
        
        let targetX = puzzleCenter.x - CGFloat(gridSize - 1) * (computedPieceSize + 5) / 2 + CGFloat(col) * (computedPieceSize + 5)
        let targetY = puzzleCenter.y - CGFloat(gridSize - 1) * (computedPieceSize + 5) / 2 + CGFloat(row) * (computedPieceSize + 5)
        
        let distance = sqrt(pow(location.x - targetX, 2) + pow(location.y - targetY, 2))
        
        if distance < computedPieceSize * 0.6 {
            if let index = pieces.firstIndex(where: { $0.id == piece.id }) {
                withAnimation {
                    pieces[index].isPlaced = true
                    pieces[index].currentPosition = CGPoint(x: targetX, y: targetY)
                }
                
                if pieces.allSatisfy({ $0.isPlaced }) {
                    puzzleComplete = true
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                        onPuzzleComplete()
                    }
                }
            }
        } else {
            if let index = pieces.firstIndex(where: { $0.id == piece.id }) {
                withAnimation {
                    let randomX = CGFloat.random(in: 100...(geometry.size.width - 100))
                    let randomY = CGFloat.random(in: geometry.size.height * 0.65...geometry.size.height * 0.85)
                    pieces[index].currentPosition = CGPoint(x: randomX, y: randomY)
                }
            }
        }
    }
    
    @ViewBuilder
    func signPieceView(for index: Int) -> some View {
        let row = index / gridSize
        let col = index % gridSize
        
        if let imageName = imageName {
            Image(imageName)
                .resizable()
                .frame(width: computedPieceSize * CGFloat(gridSize), height: computedPieceSize * CGFloat(gridSize), alignment: .topLeading)
                .offset(x: -CGFloat(col) * computedPieceSize, y: -CGFloat(row) * computedPieceSize)
                .frame(width: computedPieceSize, height: computedPieceSize, alignment: .topLeading)
                .clipped()
        } else {
            switch signType {
            case .dontWalk:
                ZStack {
                    RoundedRectangle(cornerRadius: 5)
                        .fill(Color.orange.opacity(0.9))
                    
                    if row == 0 && col == 0 {
                        Image(systemName: "hand.raised.fill")
                            .font(.system(size: 30))
                            .foregroundColor(.red)
                            .offset(x: 10, y: 10)
                    } else if row == 0 && col == 1 {
                        Image(systemName: "hand.raised.fill")
                            .font(.system(size: 30))
                            .foregroundColor(.red)
                            .offset(x: -10, y: 10)
                    } else if row == 1 && col == 0 {
                        if !appState.isSimpleMode {
                            Text("DON'T")
                                .font(.system(size: 10, weight: .bold))
                                .foregroundColor(.red)
                        }
                    } else {
                        if !appState.isSimpleMode {
                            Text("WALK")
                                .font(.system(size: 10, weight: .bold))
                                .foregroundColor(.red)
                        }
                    }
                }
                
            case .turnLeft:
                ZStack {
                    RoundedRectangle(cornerRadius: 5)
                        .fill(Color.blue.opacity(0.9))
                    
                    if row == 0 && col == 0 {
                        Image(systemName: "arrow.turn.up.left")
                            .font(.system(size: 25))
                            .foregroundColor(.white)
                            .offset(x: 10, y: 10)
                    } else if row == 0 && col == 1 {
                        Image(systemName: "arrow.turn.up.left")
                            .font(.system(size: 25))
                            .foregroundColor(.white)
                            .offset(x: -10, y: 10)
                    } else if row == 1 && col == 0 {
                        Image(systemName: "arrow.turn.up.left")
                            .font(.system(size: 25))
                            .foregroundColor(.white)
                            .offset(x: 10, y: -10)
                    } else {
                        Image(systemName: "arrow.turn.up.left")
                            .font(.system(size: 25))
                            .foregroundColor(.white)
                            .offset(x: -10, y: -10)
                    }
                }
                
            case .noUTurn:
                ZStack {
                    RoundedRectangle(cornerRadius: 40)
                        .fill(Color.white)
                    
                    if row == 0 && col == 0 {
                        ZStack {
                            Arc(startAngle: .degrees(180), endAngle: .degrees(270))
                                .stroke(Color.red, lineWidth: 4)
                            Image(systemName: "u.turn.left.fill")
                                .font(.system(size: 20))
                                .foregroundColor(.black)
                                .offset(x: 5, y: 5)
                        }
                    } else if row == 0 && col == 1 {
                        ZStack {
                            Arc(startAngle: .degrees(270), endAngle: .degrees(360))
                                .stroke(Color.red, lineWidth: 4)
                            Image(systemName: "u.turn.left.fill")
                                .font(.system(size: 20))
                                .foregroundColor(.black)
                                .offset(x: -5, y: 5)
                        }
                    } else if row == 1 && col == 0 {
                        ZStack {
                            Arc(startAngle: .degrees(90), endAngle: .degrees(180))
                                .stroke(Color.red, lineWidth: 4)
                            Rectangle()
                                .fill(Color.red)
                                .frame(width: 45, height: 4)
                                .rotationEffect(.degrees(45))
                                .offset(x: 5, y: -5)
                        }
                    } else {
                        ZStack {
                            Arc(startAngle: .degrees(0), endAngle: .degrees(90))
                                .stroke(Color.red, lineWidth: 4)
                            Rectangle()
                                .fill(Color.red)
                                .frame(width: 45, height: 4)
                                .rotationEffect(.degrees(45))
                                .offset(x: -5, y: -5)
                        }
                    }
                }
            }
        }
    }
}

// MARK: - Arc Shape
struct Arc: Shape {
    let startAngle: Angle
    let endAngle: Angle
    
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.addArc(
            center: CGPoint(x: rect.midX, y: rect.midY),
            radius: rect.width / 2,
            startAngle: startAngle,
            endAngle: endAngle,
            clockwise: false
        )
        return path
    }
}

// MARK: - Choice Puzzle Content View
struct ChoicePuzzleContentView: View {
    let question: String?
    let options: [String]
    let correctAnswer: String
    let categoryColor: Color
    let onCorrect: () -> Void
    @Binding var message: String
    
    @State private var selectedOption: String?
    
    var body: some View {
        VStack(spacing: 20) {
            if let question = question {
                Text(question)
                    .font(.title2)
                    .foregroundColor(.white)
                    .padding()
            }
            
            ForEach(options, id: \.self) { option in
                Button(action: {
                    selectedOption = option
                    if option == correctAnswer {
                        SoundManager.shared.playCorrect()
                        message = "Correct!"
                        onCorrect()
                    } else {
                        SoundManager.shared.playError()
                        message = "Try Again"
                    }
                }) {
                    Text(option)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(selectedOption == option ? 
                                    (option == correctAnswer ? Color.green : Color.red) : 
                                        Color.gray.opacity(0.3))
                        .cornerRadius(10)
                        .foregroundColor(.white)
                }
            }
        }
        .padding()
        .funBackground()
    }
}

// MARK: - Pathfinding Puzzle View
struct PathfindingPuzzleView: View {
    let categoryId: String
    let categoryColor: Color
    let onCorrect: () -> Void
    let onComplete: () -> Void
    @EnvironmentObject var appState: AppState
    
    @State private var grid: [[GridCell]] = []
    @State private var playerPosition: (row: Int, col: Int) = (1, 1)
    @State private var showWin = false
    @State private var animatedCars: [(row: Int, col: Int)] = []
    @State private var carAnimationTimer: Timer?
    @State private var lightTimer: Timer?
    @State private var showWarning = false
    @State private var warningMessage = ""
    @State private var hasMovedOnce = false
    
    let gridSize = 7
    let cellSize: CGFloat = 50
    
    var body: some View {
        ZStack {
            LinearGradient(colors: [.blue.opacity(0.3), .purple.opacity(0.3), .pink.opacity(0.3)], 
                           startPoint: .topLeading, endPoint: .bottomTrailing)
            .ignoresSafeArea()
            
            VStack(spacing: 20) {
                VStack(spacing: 2) {
                    ForEach(0..<gridSize, id: \.self) { row in
                        HStack(spacing: 2) {
                            ForEach(0..<gridSize, id: \.self) { col in
                                if let cell = grid[safe: row]?[safe: col] {
                                    GridCellView(
                                        cell: cell,
                                        isPlayer: playerPosition.row == row && playerPosition.col == col,
                                        categoryId: categoryId,
                                        categoryColor: categoryColor,
                                        hasAnimatedCar: animatedCars.contains(where: { $0.row == row && $0.col == col })
                                    )
                                    .frame(width: cellSize, height: cellSize)
                                } else {
                                    Rectangle()
                                        .fill(Color.gray)
                                        .frame(width: cellSize, height: cellSize)
                                }
                            }
                        }
                    }
                }
                .background(Color.gray.opacity(0.2))
                .cornerRadius(10)
                
                VStack(spacing: 15) {
                    Button(action: { 
                        SoundManager.shared.playTap()
                        movePlayer(direction: .up) 
                    }) {
                        Image(systemName: "arrow.up.circle.fill")
                            .font(.system(size: 60))
                            .foregroundColor(categoryColor)
                    }
                    
                    HStack(spacing: 40) {
                        Button(action: { 
                            SoundManager.shared.playTap()
                            movePlayer(direction: .left) 
                        }) {
                            Image(systemName: "arrow.left.circle.fill")
                                .font(.system(size: 60))
                                .foregroundColor(categoryColor)
                        }
                        
                        Button(action: { 
                            SoundManager.shared.playTap()
                            movePlayer(direction: .down) 
                        }) {
                            Image(systemName: "arrow.down.circle.fill")
                                .font(.system(size: 60))
                                .foregroundColor(categoryColor)
                        }
                        
                        Button(action: { 
                            SoundManager.shared.playTap()
                            movePlayer(direction: .right) 
                        }) {
                            Image(systemName: "arrow.right.circle.fill")
                                .font(.system(size: 60))
                                .foregroundColor(categoryColor)
                        }
                    }
                }
            }
            
            if showWin {
                VStack {
                    HStack {
                        Spacer()
                        ZStack {
                            Circle()
                                .fill(Color.green)
                                .frame(width: 120, height: 120)
                                .shadow(radius: 20)
                            Image(systemName: "checkmark")
                                .font(.system(size: 60, weight: .bold))
                                .foregroundColor(.white)
                        }
                        .padding(.trailing, 40)
                        .padding(.top, 80)
                    }
                    Spacer()
                }
            }
            
            if showWarning {
                VStack {
                    Text(warningMessage)
                        .font(.system(size: 50))
                        .padding()
                        .background(Color.red.opacity(0.8))
                        .cornerRadius(20)
                        .shadow(radius: 10)
                    Spacer()
                }
                .padding(.top, 100)
                .transition(.scale.combined(with: .opacity))
            }
        }
        .onAppear {
            setupGrid()
            hasMovedOnce = false
            showWin = false
            startAnimations()
        }
        .onDisappear {
            stopAnimations()
        }
    }
    
    enum Direction {
        case up, down, left, right
    }
    
    func movePlayer(direction: Direction) {
        var newRow = playerPosition.row
        var newCol = playerPosition.col
        
        switch direction {
        case .up: newRow -= 1
        case .down: newRow += 1
        case .left: newCol -= 1
        case .right: newCol += 1
        }
        
        guard newRow >= 0 && newRow < gridSize && newCol >= 0 && newCol < gridSize else {
            showWarningMessage("🚧")
            return
        }
        
        guard let targetCell = grid[safe: newRow]?[safe: newCol], targetCell.isWalkable else {
            showWarningMessage("🚫")
            return
        }
        
        if targetCell.hasTrafficLight && targetCell.trafficLightColor == .red {
            showWarningMessage(appState.isSimpleMode ? "🔴 ✋" : "🔴 Wait!")
            return
        }
        
        if animatedCars.contains(where: { $0.row == newRow && $0.col == newCol }) {
            showWarningMessage(appState.isSimpleMode ? "🚗 💥" : "🚗 Car!")
            return
        }
        
        withAnimation(.easeInOut(duration: 0.2)) {
            playerPosition = (newRow, newCol)
            hasMovedOnce = true
        }
        
        if targetCell.isGoal && hasMovedOnce {
            showWin = true
            onCorrect()
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                stopAnimations()
                onComplete()
            }
        }
    }
    
    func showWarningMessage(_ message: String) {
        SoundManager.shared.playError()
        warningMessage = message
        showWarning = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
            showWarning = false
        }
    }
    
    func setupGrid() {
        grid = (0..<gridSize).map { row in
            (0..<gridSize).map { col in
                GridCell(row: row, col: col, isWalkable: true)
            }
        }
        
        playerPosition = (1, 1)
        
        switch categoryId {
        case "pedestrian": setupPedestrianGrid()
        case "cyclist": setupCyclistGrid()
        case "driver": setupDriverGrid()
        case "traffic": setupTrafficGrid()
        default: 
            grid[1][1].isStart = true
            grid[gridSize-2][gridSize-2].isGoal = true
        }
    }
    
    func setupPedestrianGrid() {
        playerPosition = (1, 1)
        grid[1][1].isStart = true
        grid[5][5].isGoal = true
        
        for row in 0..<gridSize {
            grid[row][3].isWalkable = false
            grid[row][3].isRoad = true
        }
        
        grid[2][3].isWalkable = true
        grid[2][3].hasZebraCrossing = true
        grid[2][3].hasTrafficLight = true
        grid[2][3].trafficLightColor = .red
        grid[2][3].isRoad = true
        
        grid[4][3].isWalkable = true
        grid[4][3].hasZebraCrossing = true
        grid[4][3].hasTrafficLight = true
        grid[4][3].trafficLightColor = .green
        grid[4][3].isRoad = true
        
        grid[3][3].isWalkable = true
        grid[3][3].hasPedestrianSignal = true
        grid[3][3].pedestrianSignalColor = .red
        grid[3][3].isRoad = true
        
        animatedCars = [(1, 3), (5, 3)]
    }
    
    func setupCyclistGrid() {
        playerPosition = (1, 1)
        grid[1][1].isStart = true
        grid[5][5].isGoal = true
        
        for col in 0..<gridSize {
            grid[3][col].isWalkable = false
            grid[3][col].isRoad = true
        }
        
        grid[3][2].isWalkable = true
        grid[3][2].hasBikeLane = true
        grid[3][2].isRoad = true
        grid[3][2].hasTrafficLight = true
        grid[3][2].trafficLightColor = .red
        
        grid[3][4].isWalkable = true
        grid[3][4].hasBikeLane = true
        grid[3][4].isRoad = true
        grid[3][4].hasTrafficLight = true
        grid[3][4].trafficLightColor = .green
        
        grid[2][2].hasSign = "bicycle"
        grid[4][4].hasSign = "bicycle"
        
        grid[3][3].hasBikeLane = true
        grid[3][3].isWalkable = true
        grid[3][3].isRoad = true
        grid[3][3].hasTrafficLight = true
        grid[3][3].trafficLightColor = .green
    }
    
    func setupDriverGrid() {
        playerPosition = (1, 1)
        grid[1][1].isStart = true
        grid[5][1].isGoal = true
        
        for row in 0..<gridSize {
            grid[row][3].isWalkable = false
            grid[row][3].isRoad = true
        }
        
        for col in 0..<gridSize {
            grid[3][col].isWalkable = false
            grid[3][col].isRoad = true
        }
        
        grid[3][3].hasTrafficLight = false
        grid[3][3].isWalkable = false
        grid[3][3].isRoad = true
        
        grid[3][1].isWalkable = true
        grid[3][1].isRoad = true
        
        grid[4][1].hasTrafficLight = true
        grid[4][1].trafficLightColor = .red
        
        grid[3][5].isWalkable = true
        grid[3][5].isRoad = true
        
        grid[1][3].isWalkable = true
        grid[1][3].isRoad = true
        grid[5][3].isWalkable = true
        grid[5][3].isRoad = true
        
        grid[2][2].isNoTurnZone = true
        grid[2][4].hasSign = "arrow.turn.up.right"
        grid[4][2].hasSign = "noentry"
    }
    
    func setupTrafficGrid() {
        playerPosition = (1, 1)
        grid[1][1].isStart = true
        grid[5][5].isGoal = true
        
        for row in 0..<gridSize {
            if row != 1 && row != 5 {
                grid[row][3].isWalkable = false
                grid[row][3].isRoad = true
            }
        }
        
        for col in 0..<gridSize {
            if col != 1 && col != 5 {
                grid[3][col].isWalkable = false
                grid[3][col].isRoad = true
            }
        }
        
        grid[3][3].hasTrafficLight = false
        grid[3][3].isWalkable = true
        grid[3][3].hasZebraCrossing = true
        grid[3][3].hasPedestrianSignal = true
        grid[3][3].pedestrianSignalColor = .green
        grid[3][3].isRoad = true
        
        grid[1][3].isWalkable = true
        grid[1][3].isRoad = true
        
        grid[5][3].isWalkable = true
        grid[5][3].isRoad = true
        grid[5][3].hasTrafficLight = true
        grid[5][3].trafficLightColor = .red
        
        grid[3][1].isWalkable = true
        grid[3][1].isRoad = true
        
        grid[3][5].isWalkable = true
        grid[3][5].isRoad = true
        grid[3][5].hasTrafficLight = true
        grid[3][5].trafficLightColor = .red
        
        grid[4][4].isSchoolZone = true
        grid[2][2].hasSign = "figure.walk"
        grid[4][2].hasSign = "exclamationmark.triangle"
        
        animatedCars = [(1, 3), (3, 1), (5, 3), (3, 5)]
    }
    
    func startAnimations() {
        lightTimer = Timer.scheduledTimer(withTimeInterval: 3.0, repeats: true) { _ in
            DispatchQueue.main.async {
                withAnimation {
                    for row in 0..<self.gridSize {
                        for col in 0..<self.gridSize {
                            if self.grid[row][col].hasTrafficLight {
                                self.grid[row][col].trafficLightColor = self.grid[row][col].trafficLightColor == .red ? .green : .red
                            }
                            if self.grid[row][col].hasPedestrianSignal {
                                self.grid[row][col].pedestrianSignalColor = self.grid[row][col].pedestrianSignalColor == .red ? .green : .red
                            }
                        }
                    }
                }
            }
        }
        
        if !animatedCars.isEmpty {
            carAnimationTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
                DispatchQueue.main.async {
                    withAnimation {
                        self.animatedCars = self.animatedCars.map { (row, col) in
                            let direction = categoryId == "cyclist" || categoryId == "driver" ? 
                            Int.random(in: 0...1) : 0
                            
                            var nextPos = (row, col)
                            if direction == 0 {
                                let newRow = (row + 1) % self.gridSize
                                nextPos = (newRow, col)
                            } else {
                                let newCol = (col + 1) % self.gridSize
                                nextPos = (row, newCol)
                            }
                            
                            if nextPos.0 == self.playerPosition.row && nextPos.1 == self.playerPosition.col {
                                return (row, col)
                            }
                            
                            return nextPos
                        }
                    }
                }
            }
        }
    }
    
    func stopAnimations() {
        carAnimationTimer?.invalidate()
        lightTimer?.invalidate()
        carAnimationTimer = nil
        lightTimer = nil
    }
}

// MARK: - Grid Cell View
struct GridCellView: View {
    let cell: GridCell
    let isPlayer: Bool
    let categoryId: String
    let categoryColor: Color
    let hasAnimatedCar: Bool
    
    var body: some View {
        ZStack {
            Rectangle()
                .fill(cell.isWalkable ? Color.white : Color.gray.opacity(0.8))
            
            if cell.isRoad {
                Rectangle()
                    .fill(Color.gray.opacity(0.6))
            }
            
            if cell.hasZebraCrossing {
                HStack(spacing: 2) {
                    ForEach(0..<3) { _ in
                        Rectangle()
                            .fill(Color.white)
                            .frame(width: 8)
                    }
                }
            }
            
            if cell.hasBikeLane {
                Rectangle()
                    .stroke(Color.green, lineWidth: 2)
            }
            
            if cell.isStart {
                Circle()
                    .fill(Color.green.opacity(0.3))
            }
            
            if cell.isGoal {
                ZStack {
                    Circle()
                        .fill(Color.yellow.opacity(0.5))
                    Image(systemName: "flag.checkered")
                        .foregroundColor(.green)
                        .font(.system(size: 20))
                }
            }
            
            if cell.hasTrafficLight {
                Circle()
                    .fill(cell.trafficLightColor.color)
                    .frame(width: 20, height: 20)
                    .shadow(color: cell.trafficLightColor.color, radius: 5)
            }
            
            if cell.hasPedestrianSignal {
                Circle()
                    .fill(cell.pedestrianSignalColor == .red ? Color.red : Color.green)
                    .frame(width: 15, height: 15)
                    .overlay(
                        Image(systemName: "figure.walk")
                            .font(.system(size: 8))
                            .foregroundColor(.white)
                    )
            }
            
            if let sign = cell.hasSign {
                Image(systemName: sign)
                    .foregroundColor(.blue)
                    .font(.system(size: 16))
            }
            
            if cell.isSchoolZone {
                Image(systemName: "book.fill")
                    .foregroundColor(.yellow)
                    .font(.system(size: 16))
            }
            
            if cell.isNoTurnZone {
                Image(systemName: "nosign")
                    .foregroundColor(.red)
                    .font(.system(size: 16))
            }
            
            if hasAnimatedCar {
                Image(systemName: "car.fill")
                    .foregroundColor(.red)
                    .font(.system(size: 16))
            }
            
            if isPlayer {
                ZStack {
                    Circle()
                        .fill(categoryColor.opacity(0.3))
                    Image(systemName: playerIcon)
                        .foregroundColor(categoryColor)
                        .font(.system(size: 24))
                }
            }
        }
        .border(Color.gray.opacity(0.3), width: 1)
    }
    
    var playerIcon: String {
        switch categoryId {
        case "pedestrian": return "figure.walk"
        case "cyclist": return "bicycle"
        case "driver": return "car.fill"
        case "traffic": return "figure.walk"
        default: return "figure.walk"
        }
    }
}

// MARK: - Completion View
struct CompletionView: View {
    let score: Int
    let totalPossible: Int
    let rating: PerformanceRating
    let categoryColor: Color
    let onContinue: () -> Void    
    
    @EnvironmentObject var appState: AppState
    @State private var scale: CGFloat = 0.5
    @State private var opacity: Double = 0
    @State private var flameScale: CGFloat = 1.0
    
    var body: some View {
        ZStack {
            Color.black.opacity(0.7)
                .ignoresSafeArea()
            
            VStack(spacing: 40) {
                ZStack {
                    Circle()
                        .fill(rating.color)
                        .frame(width: 120, height: 120)
                        .scaleEffect(scale)
                    
                    Text(rating.icon)
                        .font(.system(size: 70))
                        .scaleEffect(flameScale)
                }
                
                VStack(spacing: 10) {
                    if !appState.isSimpleMode {
                        Text("Level Complete!")
                            .font(.title3)
                            .foregroundColor(.white.opacity(0.8))
                        
                        Text("\(score)")
                            .font(.system(size: 60, weight: .bold))
                            .foregroundColor(.white)
                        
                        Text(rating.message)
                            .font(.title2)
                            .foregroundColor(rating.color)
                    } else {
                        // In Simple Mode, just show Score BIG
                        Text("\(score)")
                            .font(.system(size: 80, weight: .bold))
                            .foregroundColor(.white)
                    }
                }
                
                VStack(spacing: 8) {
                    if !appState.isSimpleMode {
                        Text("Total Score")
                            .font(.headline)
                            .foregroundColor(.white.opacity(0.7))
                    }
                    
                    HStack {
                        Image(systemName: "star.fill")
                            .font(.title)
                            .foregroundColor(.yellow)
                        Text("\(appState.totalScore)")
                            .font(.system(size: 40, weight: .bold))
                            .foregroundColor(.orange)
                    }
                }
                
                Button(action: onContinue) {
                    HStack {
                        if !appState.isSimpleMode {
                            Text("Continue")
                                .font(.title3)
                                .fontWeight(.bold)
                        } else {
                            Image(systemName: "arrow.right.circle.fill")
                                .font(.largeTitle)
                        }
                    }
                    .foregroundColor(.white)
                    .padding(.horizontal, 50)
                    .padding(.vertical, 15)
                    .background(categoryColor)
                    .cornerRadius(25)
                    .shadow(radius: 10)
                }
                .padding(.top, 30)
            }
            .padding(40)
            .background(
                RoundedRectangle(cornerRadius: 30)
                    .fill(Color.white.opacity(0.1))
                    .background(.ultraThinMaterial)
                    .cornerRadius(30)
            )
            
            .padding(30)
            .scaleEffect(scale)
            .opacity(opacity)
        }
        .onAppear {
            withAnimation(.spring(response: 0.6, dampingFraction: 0.7)) {
                scale = 1.0
                opacity = 1.0
            }
            
            if rating == .excellent {
                withAnimation(.easeInOut(duration: 0.3).repeatForever(autoreverses: true)) {
                    flameScale = 1.2
                }
            }
        }
    }
}

// MARK: - Racing Game Components
struct RoadBackgroundView: View {
    let speed: CGFloat
    let isStopped: Bool
    @State private var offset: CGFloat = 0
    
    var body: some View {
        GeometryReader { geo in
            ZStack {
                Color.gray // Asphalt
                
                // Lane Markings
                Canvas { context, size in
                    let laneWidth = size.width / 3
                    for i in 1...2 {
                        let x = CGFloat(i) * laneWidth
                        var path = Path()
                        path.move(to: CGPoint(x: x, y: 0))
                        path.addLine(to: CGPoint(x: x, y: size.height))
                        context.stroke(path, with: .color(.white.opacity(0.3)), style: StrokeStyle(lineWidth: 4, dash: [40, 40], dashPhase: offset))
                    }
                }
            }
        }
        .onAppear {
            if !isStopped {
                withAnimation(.linear(duration: 0.5).repeatForever(autoreverses: false)) {
                    offset = 80
                }
            }
        }
    }
}

struct CarStencilView: View {
    let color: Color
    var isPlayer: Bool = false
    
    var body: some View {
        ZStack {
            Image(systemName: isPlayer ? "car.fill" : "car.2.fill")
                .font(.system(size: 60))
                .foregroundColor(color)
                .shadow(color: color.opacity(0.5), radius: 5)
            
            // Stencil effect: inner outline
            Image(systemName: isPlayer ? "car.fill" : "car.2.fill")
                .font(.system(size: 58))
                .foregroundColor(.black.opacity(0.2))
                .blendMode(.destinationOut)
        }
        .compositingGroup()
    }
}

struct PlayerCarView: View {
    var body: some View {
        CarStencilView(color: .blue, isPlayer: true)
    }
}

struct ObstacleView: View {
    let obstacle: RacingObstacle
    let laneWidth: CGFloat
    
    var body: some View {
        Group {
            switch obstacle.type {
            case .zebraCrossing:
                ZStack {
                    // Zebra stripes
                    VStack(spacing: 12) {
                        ForEach(0..<6) { _ in
                            Rectangle()
                                .fill(Color.white.opacity(0.4))
                                .frame(width: laneWidth * 3, height: 8)
                        }
                    }
                    
                    // Lane-specific lights
                    HStack(spacing: 0) {
                        ForEach(0..<3) { lane in
                            VStack {
                                Circle()
                                    .fill(isLaneOccupied(lane) ? Color.red : Color.green)
                                    .frame(width: 15, height: 15)
                                    .shadow(color: isLaneOccupied(lane) ? .red : .green, radius: 10)
                                    .overlay(Circle().stroke(Color.white, lineWidth: 1))
                                Spacer()
                            }
                            .frame(width: laneWidth)
                        }
                    }
                    .padding(.top, 5)
                    
                    // Pedestrians
                    ForEach(obstacle.pedestrians) { pedestrian in
                        Text("🚶‍♂️")
                            .font(.system(size: 35))
                            .offset(x: pedestrian.xOffset * laneWidth * 1.5)
                    }
                    
                    // Side Traffic Light
                    HStack {
                        VStack(spacing: 4) {
                            Circle().fill(obstacle.lightState == .yellow ? Color.yellow : Color.gray.opacity(0.3)).frame(width: 10, height: 10)
                            Circle().fill(obstacle.lightState == .green ? Color.green : Color.gray.opacity(0.3)).frame(width: 10, height: 10)
                        }
                        .padding(5)
                        .background(Color.black.opacity(0.6))
                        .cornerRadius(5)
                        Spacer()
                    }
                    .frame(width: laneWidth * 3 + 40)
                }
                
            case .noEntrySign:
                Image(systemName: "minus.circle.fill")
                    .font(.system(size: 60))
                    .foregroundColor(.red)
                    .background(Circle().fill(.white))
                
            case .pedestrianCrossing:
                ZStack {
                    Rectangle().fill(.white.opacity(0.3)).frame(width: laneWidth * 3, height: 120)
                    Text("🚶‍♂️")
                        .font(.system(size: 50))
                }
                
            case .oncomingCar:
                CarStencilView(color: .red)
                    .rotationEffect(.degrees(180))
            }
        }
    }
    
    private func isLaneOccupied(_ lane: Int) -> Bool {
        let laneCenterRelative = CGFloat(lane) * laneWidth + laneWidth/2 - (laneWidth * 1.5)
        return obstacle.pedestrians.contains(where: { ped in
            let pedX = ped.xOffset * laneWidth * 1.5
            return abs(pedX - laneCenterRelative) < laneWidth/2
        })
    }
}

struct RacingGameView: View {
    @StateObject var gameState = RacingGameState()
    @EnvironmentObject var appState: AppState
    let onComplete: (Int) -> Void
    
    let timer = Timer.publish(every: 0.05, on: .main, in: .common).autoconnect()
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                // Road
                RoadBackgroundView(speed: gameState.speed, isStopped: gameState.isStopped)
                
                // Obstacles
                ForEach(gameState.obstacles) { obstacle in
                    ObstacleView(obstacle: obstacle, laneWidth: geometry.size.width / 3)
                        .position(x: obstacleX(obstacle: obstacle, width: geometry.size.width),
                                  y: obstacle.yPosition)
                }
                
                // Player Car
                PlayerCarView()
                    .position(x: laneCenter(lane: gameState.playerLane, width: geometry.size.width),
                              y: geometry.size.height * 0.5)
                    .gesture(
                        DragGesture()
                            .onEnded { value in
                                if value.translation.width < -30 {
                                    withAnimation { gameState.playerLane = max(0, gameState.playerLane - 1) }
                                } else if value.translation.width > 30 {
                                    withAnimation { gameState.playerLane = min(2, gameState.playerLane + 1) }
                                }
                            }
                    )
                
                // Controls & HUD
                VStack {
                    HStack {
                        VStack(alignment: .leading) {
                            Text("Distance")
                                .font(.caption.bold())
                            Text("\(gameState.distance)m")
                                .font(.title2.bold())
                        }
                        .padding()
                        .background(.ultraThinMaterial)
                        .cornerRadius(15)
                        
                        Spacer()
                        
                        Button(action: { 
                            SoundManager.shared.playTap()
                            gameState.isPaused.toggle() 
                        }) {
                            Image(systemName: gameState.isPaused ? "play.fill" : "pause.fill")
                                .font(.title)
                                .padding()
                                .background(.ultraThinMaterial)
                                .clipShape(Circle())
                        }
                    }
                    .padding()
                    
                    if gameState.gameOver {
                        VStack {
                            Text("GAME OVER")
                                .font(.system(size: 50, weight: .black))
                                .foregroundColor(.red)
                            Text("Final Distance: \(gameState.distance)m")
                                .font(.title)
                            Button("Continue") {
                                SoundManager.shared.playTap()
                                onComplete(gameState.distance)
                            }
                            .padding()
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(15)
                        }
                        .padding()
                        .background(.white.opacity(0.9))
                        .cornerRadius(30)
                        .shadow(radius: 20)
                    }
                    
                    Spacer()
                    
                    // Lane Controls
                    HStack(spacing: 30) {
                        controlButton(icon: "arrow.left") {
                            withAnimation { gameState.playerLane = max(0, gameState.playerLane - 1) }
                        }
                        
                        Button(action: {
                            SoundManager.shared.playTap()
                            // Find closest zebra crossing
                            let closestZebra = gameState.obstacles.first(where: { 
                                if case .zebraCrossing = $0.type { return $0.yPosition > 0 && $0.yPosition < geometry.size.height }
                                return false
                            })
                            
                            if let zebra = closestZebra {
                                if zebra.lightState == .yellow {
                                    gameState.isStopped = true
                                } else if zebra.lightState == .green {
                                    gameState.isStopped = false
                                } else {
                                    gameState.isStopped.toggle()
                                }
                            } else {
                                gameState.isStopped.toggle()
                            }
                        }) {
                            VStack {
                                Image(systemName: gameState.isStopped ? "play.circle.fill" : "stop.circle.fill")
                                    .font(.system(size: 60))
                                Text(gameState.isStopped ? "RESUME" : "WAIT")
                                    .font(.caption.bold())
                            }
                            .foregroundColor(gameState.isStopped ? .green : .red)
                        }
                        
                        controlButton(icon: "arrow.right") {
                            withAnimation { gameState.playerLane = min(2, gameState.playerLane + 1) }
                        }
                    }
                    .padding(.bottom, 50)
                }
                
                if gameState.isPaused {
                    Color.black.opacity(0.4)
                        .ignoresSafeArea()
                        .overlay(
                            Text("PAUSED")
                                .font(.largeTitle.bold())
                                .foregroundColor(.white)
                        )
                        .onTapGesture { gameState.isPaused = false }
                }
            }
            .onReceive(timer) { _ in
                updateGame(width: geometry.size.width, height: geometry.size.height)
            }
        }
    }
    
    private func controlButton(icon: String, action: @escaping () -> Void) -> some View {
        Button(action: {
            SoundManager.shared.playTap()
            action()
        }) {
            Image(systemName: icon)
                .font(.system(size: 40, weight: .bold))
                .foregroundColor(.white)
                .padding(25)
                .background(Circle().fill(Color.blue.opacity(0.8)))
                .shadow(radius: 10)
        }
    }
    
    private func laneCenter(lane: Int, width: CGFloat) -> CGFloat {
        let laneWidth = width / 3
        return CGFloat(lane) * laneWidth + laneWidth / 2
    }
    
    private func obstacleX(obstacle: RacingObstacle, width: CGFloat) -> CGFloat {
        let laneWidth = width / 3
        switch obstacle.type {
        case .zebraCrossing, .pedestrianCrossing:
            return width / 2
        case .noEntrySign(let lane), .oncomingCar(let lane):
            return laneCenter(lane: lane, width: width)
        }
    }
    
    private func updateGame(width: CGFloat, height: CGFloat) {
        guard !gameState.gameOver && !gameState.isPaused else { return }
        
        // Update distance and progressive speed
        if !gameState.isStopped {
            gameState.distance += Int(gameState.speed)
            gameState.speed += 0.002 // Slightly faster increase
        }
        
        // Move obstacles
        let moveSpeed = gameState.isStopped ? 0 : gameState.speed * 5
        for i in gameState.obstacles.indices {
            gameState.obstacles[i].yPosition += moveSpeed
            
            // Update zebra crossing states
            if case .zebraCrossing = gameState.obstacles[i].type {
                gameState.obstacles[i].lightTimer += 0.05
                if gameState.obstacles[i].lightTimer > 3.0 { // Toggle every 3 seconds
                    if gameState.obstacles[i].lightState == .green {
                        gameState.obstacles[i].lightState = .yellow
                    } else if gameState.obstacles[i].lightState == .yellow {
                        gameState.obstacles[i].lightState = .green
                    }
                    gameState.obstacles[i].lightTimer = 0
                }
                
                // Update pedestrians
                for j in gameState.obstacles[i].pedestrians.indices {
                    gameState.obstacles[i].pedestrians[j].xOffset += gameState.obstacles[i].pedestrians[j].direction * 0.03
                    if abs(gameState.obstacles[i].pedestrians[j].xOffset) > 1.2 {
                        gameState.obstacles[i].pedestrians[j].direction *= -1
                    }
                }
            }
        }
        
        // Spawn obstacles
        if gameState.obstacles.isEmpty || gameState.obstacles.last!.yPosition > 500 {
            spawnObstacle()
        }        
        // Cleanup
        gameState.obstacles.removeAll { $0.yPosition > height + 200 }
        
        // Collision Detection
        checkCollisions(width: width, height: height)
        
    }
    
    private func spawnObstacle() {
        let types: [ObstacleType] = [.zebraCrossing, .noEntrySign(lane: Int.random(in: 0...2)), .oncomingCar(lane: Int.random(in: 0...2))]
        let type = types.randomElement()!
        
        var obstacle = RacingObstacle(type: type, yPosition: -300)
        
        if case .zebraCrossing = type {
            // Add some pedestrians
            let count = Int.random(in: 1...3)
            for _ in 0..<count {
                obstacle.pedestrians.append(Pedestrian(xOffset: CGFloat.random(in: -1...1), direction: Bool.random() ? 1 : -1))
            }
            obstacle.lightState = .yellow // Initial state
        }
        
        gameState.obstacles.append(obstacle)
    }
    
    private func checkCollisions(width: CGFloat, height: CGFloat) {
        let playerY = height * 0.65
        let playerLane = gameState.playerLane
        let laneWidth = width / 3
        
        for obstacle in gameState.obstacles {
            let distY = abs(obstacle.yPosition - playerY)
            if distY < 80 {
                switch obstacle.type {
                case .zebraCrossing:
                    // Check if any pedestrian is in the player's lane
                    let laneCenterRelative = CGFloat(playerLane) * laneWidth + laneWidth/2 - (laneWidth * 1.5)
                    
                    for pedestrian in obstacle.pedestrians {
                        let pedX = pedestrian.xOffset * laneWidth * 1.5
                        if abs(pedX - laneCenterRelative) < laneWidth/2 {
                            if !gameState.isStopped {
                                SoundManager.shared.playError()
                                gameState.gameOver = true
                            }
                        }
                    }
                    
                    // General rule: if you move while wait light is on at zebra
                    if !gameState.isStopped && obstacle.lightState == .yellow && distY < 40 {
                        // User should have stopped
                        // Let's make it a bit lenient but if they hit the crossing while yellow and not stopped...
                        // Actually, the user says "wait until all of them goes"
                    }
                    
                case .noEntrySign(let lane):
                    if lane == playerLane && !gameState.isStopped { 
                        SoundManager.shared.playError()
                        gameState.gameOver = true 
                    }
                case .pedestrianCrossing:
                    if !gameState.isStopped { 
                        SoundManager.shared.playError()
                        gameState.gameOver = true 
                    }
                case .oncomingCar(let lane):
                    if lane == playerLane && !gameState.isStopped { 
                        SoundManager.shared.playError()
                        gameState.gameOver = true 
                    }
            
                }
                
            }
        }
    }
}



